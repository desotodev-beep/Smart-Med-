import React, { useState } from 'react';
import { ScreeningCriteria, MessageTemplate, DeliveryChannel } from '../types';
import { SCREENING_TYPES } from '../mockData';
import { Settings, Save, Sparkles, HelpCircle, Edit3, Shield, Info, Plus, Trash2 } from 'lucide-react';

interface SettingsTemplatesProps {
  criteria: ScreeningCriteria[];
  templates: MessageTemplate[];
  onUpdateCriteria: (updatedCriteria: ScreeningCriteria[]) => void;
  onUpdateTemplates: (updatedTemplates: MessageTemplate[]) => void;
  currentUserRole: string;
  channelPriority: DeliveryChannel[];
  onUpdateChannelPriority: (updatedPriority: DeliveryChannel[]) => void;
}

export const SettingsTemplates: React.FC<SettingsTemplatesProps> = ({
  criteria,
  templates,
  onUpdateCriteria,
  onUpdateTemplates,
  currentUserRole,
  channelPriority,
  onUpdateChannelPriority,
}) => {
  // Local state for editing templates
  const [localTemplates, setLocalTemplates] = useState<MessageTemplate[]>([...templates]);
  const [activeChannelTab, setActiveChannelTab] = useState<DeliveryChannel>('sms');
  const [templatesSaved, setTemplatesSaved] = useState(false);

  // Local state for editing screening rules
  const [localCriteria, setLocalCriteria] = useState<ScreeningCriteria[]>([...criteria]);
  const [criteriaSaved, setCriteriaSaved] = useState(false);

  // For adding a new custom criteria row
  const [showAddCriteria, setShowAddCriteria] = useState(false);
  const [newRule, setNewRule] = useState<ScreeningCriteria>({
    screening_type: 'fluorography',
    age_min: 18,
    age_max: 99,
    diagnosis_pattern: 'Любой',
    dispensary_group: 'Любая',
    days_since_last_screening: 365,
    schedule: 'daily',
  });

  const getScreeningName = (typeId: string) => {
    return SCREENING_TYPES.find(t => t.id === typeId)?.name || typeId;
  };

  const handleTemplateTextChange = (channel: DeliveryChannel, newText: string) => {
    setLocalTemplates(prev =>
      prev.map(t => (t.channel === channel ? { ...t, text_with_placeholders: newText } : t))
    );
    setTemplatesSaved(false);
  };

  const handleInsertTag = (channel: DeliveryChannel, tag: string) => {
    const activeT = localTemplates.find(t => t.channel === channel);
    if (!activeT) return;

    const textarea = document.getElementById(`textarea-${channel}`) as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentText = activeT.text_with_placeholders;

    const updatedText = currentText.substring(0, start) + tag + currentText.substring(end);
    handleTemplateTextChange(channel, updatedText);

    // Refocus and place cursor
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + tag.length, start + tag.length);
    }, 50);
  };

  const handleSaveTemplates = () => {
    onUpdateTemplates(localTemplates);
    setTemplatesSaved(true);
    setTimeout(() => setTemplatesSaved(false), 2000);
  };

  const handleCriteriaChange = (index: number, field: keyof ScreeningCriteria, value: any) => {
    setLocalCriteria(prev =>
      prev.map((c, idx) => (idx === index ? { ...c, [field]: value } : c))
    );
    setCriteriaSaved(false);
  };

  const handleSaveCriteria = () => {
    onUpdateCriteria(localCriteria);
    setCriteriaSaved(true);
    setTimeout(() => setCriteriaSaved(false), 2000);
  };

  const handleAddCriteriaRule = () => {
    const updated = [...localCriteria, newRule];
    setLocalCriteria(updated);
    onUpdateCriteria(updated);
    setShowAddCriteria(false);
    // reset form
    setNewRule({
      screening_type: 'fluorography',
      age_min: 18,
      age_max: 99,
      diagnosis_pattern: 'Любой',
      dispensary_group: 'Любая',
      days_since_last_screening: 365,
      schedule: 'daily',
    });
  };

  const handleDeleteCriteriaRule = (index: number) => {
    const updated = localCriteria.filter((_, idx) => idx !== index);
    setLocalCriteria(updated);
    onUpdateCriteria(updated);
  };

  const isDirector = currentUserRole === 'director';
  const canEdit = currentUserRole === 'coordinator' || currentUserRole === 'admin' || currentUserRole === 'doctor';

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      {/* PANEL 1: SHABLONY / MESSAGE TEMPLATES */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-6 flex flex-col justify-between">
        <div className="space-y-4">
          <div>
            <h4 className="text-base font-bold text-gray-900">Редактор шаблонов оповещений</h4>
            <p className="text-xs text-gray-500 mt-0.5">Настройка текстов SMS, Push-уведомлений и мессенджеров с тегами подстановки КМИС</p>
          </div>

          {/* Tabs for channel */}
          <div className="flex bg-gray-50 p-1.5 rounded-xl border border-gray-100 text-xs font-semibold">
            {(['sms', 'push', 'messenger'] as DeliveryChannel[]).map(ch => (
              <button
                key={ch}
                onClick={() => setActiveChannelTab(ch)}
                className={`flex-1 py-2 rounded-lg transition-all ${
                  activeChannelTab === ch
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <span className="uppercase">{ch === 'sms' ? 'SMS' : ch === 'push' ? 'Push-уведомление' : 'Viber / WhatsApp'}</span>
              </button>
            ))}
          </div>

          {/* Active Template Area */}
          {localTemplates.map(tpl => {
            if (tpl.channel !== activeChannelTab) return null;

            return (
              <div key={tpl.channel} className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400">Формат канала: <b>{activeChannelTab.toUpperCase()}</b></span>
                  <div className="flex gap-1">
                    {['{ФИО}', '{скрининг}', '{кабинет}', '{адрес}', '{дата}'].map(tag => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => handleInsertTag(tpl.channel, tag)}
                        disabled={!canEdit || isDirector}
                        className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded text-[10px] font-bold transition-all disabled:opacity-50"
                        title="Вставить тег"
                      >
                        {tag}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="relative">
                  <textarea
                    id={`textarea-${tpl.channel}`}
                    value={tpl.text_with_placeholders}
                    onChange={(e) => handleTemplateTextChange(tpl.channel, e.target.value)}
                    disabled={!canEdit || isDirector}
                    rows={6}
                    className="w-full text-xs p-4 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white font-mono leading-relaxed"
                  />
                  <div className="absolute bottom-2.5 right-3 text-[10px] text-gray-400">
                    Символов: {tpl.text_with_placeholders.length}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Placeholders instruction info box */}
          <div className="bg-blue-50/40 p-4 rounded-xl text-xs text-blue-900 border border-blue-100 flex items-start gap-2.5">
            <Info className="w-4.5 h-4.5 text-blue-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold">Как работают теги КМИС:</span>
              <p className="text-[11px] text-gray-600 leading-relaxed">
                Система автоматически заменяет теги в скобках на реальные данные при отправке. Например: <code className="font-semibold text-blue-950 font-mono">{"{ФИО}"}</code> превратится в «Иванов И.С.», а <code className="font-semibold text-blue-950 font-mono">{"{кабинет}"}</code> — в название кабинета лучевой диагностики.
              </p>
            </div>
          </div>

          {/* Channel priority editor */}
          <div className="bg-slate-50 p-4 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h5 className="text-xs font-bold text-slate-800">Приоритет каналов доставки (Failover-очередь)</h5>
                <p className="text-[10px] text-slate-500 mt-0.5">Определяет очередность опроса каналов информирования при отправке оповещения</p>
              </div>
              <span className="px-1.5 py-0.5 text-[9px] bg-indigo-50 text-indigo-600 rounded font-bold uppercase tracking-wider">Умный выбор</span>
            </div>

            <div className="space-y-1.5">
              {channelPriority.map((ch, idx) => (
                <div key={ch} className="bg-white px-3 py-2 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center font-bold text-[10px] text-slate-500">{idx + 1}</span>
                    <span className="font-semibold text-slate-700">
                      {ch === 'sms' ? '📳 SMS-оповещение' : ch === 'push' ? '📲 Push-уведомление (Мобильное приложение)' : '💬 Мессенджер (Viber / WA / Telegram)'}
                    </span>
                  </div>
                  {canEdit && !isDirector && (
                    <div className="flex gap-1">
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => {
                          const nextPriority = [...channelPriority];
                          const temp = nextPriority[idx];
                          nextPriority[idx] = nextPriority[idx - 1];
                          nextPriority[idx - 1] = temp;
                          onUpdateChannelPriority(nextPriority);
                        }}
                        className="px-1.5 py-0.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 disabled:opacity-30 rounded text-[10px] font-bold"
                        title="Поднять в приоритете"
                      >
                        ▲
                      </button>
                      <button
                        type="button"
                        disabled={idx === channelPriority.length - 1}
                        onClick={() => {
                          const nextPriority = [...channelPriority];
                          const temp = nextPriority[idx];
                          nextPriority[idx] = nextPriority[idx + 1];
                          nextPriority[idx + 1] = temp;
                          onUpdateChannelPriority(nextPriority);
                        }}
                        className="px-1.5 py-0.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 disabled:opacity-30 rounded text-[10px] font-bold"
                        title="Опустить в приоритете"
                      >
                        ▼
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="text-[10px] text-slate-500 leading-normal flex items-start gap-1.5 bg-white p-2 border border-slate-150 rounded-lg">
              <span className="shrink-0 text-amber-500">💡</span>
              <span>При запуске рассылки КМИС попытается отправить сообщение по первому каналу. При сбое доставки (например, у пациента нет телефона или не установлено приложение), система мгновенно перейдёт к следующему каналу в списке.</span>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="pt-4 border-t border-gray-100 flex justify-end">
          {!canEdit || isDirector ? (
            <div className="text-xs text-gray-400 italic">Режим просмотра. Изменение шаблонов доступно координаторам и администраторам.</div>
          ) : (
            <button
              onClick={handleSaveTemplates}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                templatesSaved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-100'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>{templatesSaved ? 'Шаблоны сохранены! ✓' : 'Сохранить шаблоны'}</span>
            </button>
          )}
        </div>
      </div>

      {/* PANEL 2: KRITERII / SCREENING CRITERIA */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-6 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-base font-bold text-gray-900">Критерии отбора целевых групп</h4>
              <p className="text-xs text-gray-500 mt-0.5">Управление алгоритмом автоматического выявления пациентов, которым положен скрининг</p>
            </div>
            {canEdit && !isDirector && (
              <button
                onClick={() => setShowAddCriteria(!showAddCriteria)}
                className="p-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg transition-all"
                title="Добавить новый критерий"
              >
                <Plus className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Form to add a new criteria rule */}
          {showAddCriteria && (
            <div className="bg-gray-50 p-4 border border-blue-100 rounded-xl text-xs space-y-3">
              <div className="font-bold text-blue-900">Новый критерий отбора</div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-gray-500 mb-1">Вид скрининга</label>
                  <select
                    value={newRule.screening_type}
                    onChange={(e) => setNewRule({ ...newRule, screening_type: e.target.value })}
                    className="w-full bg-white border border-gray-200 rounded px-2 py-1.5 focus:outline-none"
                  >
                    {SCREENING_TYPES.map(t => (
                      <option key={t.id} value={t.id}>{t.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 mb-1">Интервал (дней)</label>
                  <input
                    type="number"
                    value={newRule.days_since_last_screening}
                    onChange={(e) => setNewRule({ ...newRule, days_since_last_screening: parseInt(e.target.value) || 365 })}
                    className="w-full bg-white border border-gray-200 rounded px-2 py-1.5 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 mb-1">Мин. возраст</label>
                  <input
                    type="number"
                    value={newRule.age_min}
                    onChange={(e) => setNewRule({ ...newRule, age_min: parseInt(e.target.value) || 18 })}
                    className="w-full bg-white border border-gray-200 rounded px-2 py-1.5 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 mb-1">Макс. возраст</label>
                  <input
                    type="number"
                    value={newRule.age_max}
                    onChange={(e) => setNewRule({ ...newRule, age_max: parseInt(e.target.value) || 99 })}
                    className="w-full bg-white border border-gray-200 rounded px-2 py-1.5 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 mb-1">Коды МКБ-10 (через |)</label>
                  <input
                    type="text"
                    value={newRule.diagnosis_pattern}
                    onChange={(e) => setNewRule({ ...newRule, diagnosis_pattern: e.target.value })}
                    placeholder="Например, I10|E11"
                    className="w-full bg-white border border-gray-200 rounded px-2 py-1.5 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-500 mb-1">Группа Д-учета</label>
                  <select
                    value={newRule.dispensary_group}
                    onChange={(e) => setNewRule({ ...newRule, dispensary_group: e.target.value as any })}
                    className="w-full bg-white border border-gray-200 rounded px-2 py-1.5 focus:outline-none"
                  >
                    <option value="Любая">Любая</option>
                    <option value="Д1">Д1</option>
                    <option value="Д2">Д2</option>
                    <option value="Д3">Д3</option>
                  </select>
                </div>
              </div>
              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="button"
                  onClick={handleAddCriteriaRule}
                  className="px-3 py-1.5 bg-blue-600 text-white rounded font-bold hover:bg-blue-700"
                >
                  Добавить
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddCriteria(false)}
                  className="px-3 py-1.5 bg-white border border-gray-200 text-gray-600 rounded font-medium hover:bg-gray-50"
                >
                  Отмена
                </button>
              </div>
            </div>
          )}

          {/* Criteria table list */}
          <div className="space-y-4">
            {localCriteria.map((rule, index) => (
              <div key={index} className="bg-gray-50 p-4 border border-gray-100 rounded-xl text-xs space-y-3 relative group">
                {canEdit && !isDirector && (
                  <button
                    onClick={() => handleDeleteCriteriaRule(index)}
                    className="absolute top-3.5 right-3 text-gray-400 hover:text-rose-600 transition-colors opacity-0 group-hover:opacity-100 p-1"
                    title="Удалить правило"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}

                <div className="font-semibold text-gray-900 max-w-[90%]">
                  Правило {index + 1}: {getScreeningName(rule.screening_type)}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-1">
                  {/* Age constraint */}
                  <div>
                    <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Целевой возраст</span>
                    {canEdit && !isDirector ? (
                      <div className="flex items-center gap-1 mt-0.5">
                        <input
                          type="number"
                          value={rule.age_min}
                          onChange={(e) => handleCriteriaChange(index, 'age_min', parseInt(e.target.value) || 0)}
                          className="w-10 bg-white border border-gray-200 rounded px-1 py-0.5 font-mono text-center"
                        />
                        <span>-</span>
                        <input
                          type="number"
                          value={rule.age_max}
                          onChange={(e) => handleCriteriaChange(index, 'age_max', parseInt(e.target.value) || 0)}
                          className="w-10 bg-white border border-gray-200 rounded px-1 py-0.5 font-mono text-center"
                        />
                        <span>лет</span>
                      </div>
                    ) : (
                      <span className="font-bold text-gray-800">{rule.age_min}-{rule.age_max} лет</span>
                    )}
                  </div>

                  {/* Diagnosis */}
                  <div>
                    <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Диагноз (МКБ-10)</span>
                    {canEdit && !isDirector ? (
                      <input
                        type="text"
                        value={rule.diagnosis_pattern}
                        onChange={(e) => handleCriteriaChange(index, 'diagnosis_pattern', e.target.value)}
                        className="w-24 bg-white border border-gray-200 rounded px-1.5 py-0.5 font-mono mt-0.5"
                      />
                    ) : (
                      <span className="font-bold text-gray-800">{rule.diagnosis_pattern}</span>
                    )}
                  </div>

                  {/* Dispensary group */}
                  <div>
                    <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Группа Д-учета</span>
                    {canEdit && !isDirector ? (
                      <select
                        value={rule.dispensary_group}
                        onChange={(e) => handleCriteriaChange(index, 'dispensary_group', e.target.value)}
                        className="bg-white border border-gray-200 rounded px-1 py-0.5 mt-0.5"
                      >
                        <option value="Любая">Любая</option>
                        <option value="Д1">Д1</option>
                        <option value="Д2">Д2</option>
                        <option value="Д3">Д3</option>
                      </select>
                    ) : (
                      <span className="font-bold text-gray-800">{rule.dispensary_group}</span>
                    )}
                  </div>

                  {/* Days limit */}
                  <div>
                    <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Интервал повтора</span>
                    {canEdit && !isDirector ? (
                      <div className="flex items-center gap-1 mt-0.5">
                        <input
                          type="number"
                          value={rule.days_since_last_screening}
                          onChange={(e) => handleCriteriaChange(index, 'days_since_last_screening', parseInt(e.target.value) || 365)}
                          className="w-16 bg-white border border-gray-200 rounded px-1 py-0.5 font-mono text-center"
                        />
                        <span>дн.</span>
                      </div>
                    ) : (
                      <span className="font-bold text-gray-800">{rule.days_since_last_screening} дн.</span>
                    )}
                  </div>

                  {/* Cron schedule */}
                  <div>
                    <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Периодичность</span>
                    {canEdit && !isDirector ? (
                      <select
                        value={rule.schedule}
                        onChange={(e) => handleCriteriaChange(index, 'schedule', e.target.value)}
                        className="bg-white border border-gray-200 rounded px-1 py-0.5 mt-0.5"
                      >
                        <option value="daily">daily (Ежедневно)</option>
                        <option value="weekly">weekly (Еженедельно)</option>
                      </select>
                    ) : (
                      <span className="font-bold text-gray-800">{rule.schedule}</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action button */}
        <div className="pt-4 border-t border-gray-100 flex justify-end">
          {!canEdit || isDirector ? (
            <div className="text-xs text-gray-400 italic">Режим просмотра. Изменение критериев доступно координаторам и администраторам.</div>
          ) : (
            <button
              onClick={handleSaveCriteria}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                criteriaSaved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-100'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>{criteriaSaved ? 'Критерии сохранены! ✓' : 'Сохранить критерии'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
