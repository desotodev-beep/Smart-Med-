import React, { useState, useEffect, useMemo } from 'react';
import { Patient, ScreeningType, Invitation } from '../types';
import { SCREENING_TYPES } from '../mockData';
import { 
  TrendingUp, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  Users, 
  MessageSquare, 
  Award, 
  ArrowUpRight, 
  Calendar, 
  Download, 
  RefreshCw, 
  Printer, 
  User, 
  MapPin, 
  ShieldCheck, 
  Activity, 
  ArrowRight 
} from 'lucide-react';

interface AnalyticsDashboardProps {
  patients: Patient[];
  invitations?: Invitation[];
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ patients, invitations }) => {
  // Filters
  const [startDate, setStartDate] = useState('2026-07-01');
  const [endDate, setEndDate] = useState('2026-07-31');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [selectedScreeningType, setSelectedScreeningType] = useState('');
  
  // Data State
  const [analyticsData, setAnalyticsData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isRefreshingCache, setIsRefreshingCache] = useState(false);

  // Extract unique doctors and districts for filters
  const uniqueDistricts = useMemo(() => {
    const set = new Set<string>();
    patients.forEach(p => {
      if (p.district) set.add(p.district);
    });
    return Array.from(set);
  }, [patients]);

  const uniqueDoctors = useMemo(() => {
    const set = new Set<string>();
    patients.forEach(p => {
      if (p.assignedDoctor) set.add(p.assignedDoctor);
    });
    return Array.from(set);
  }, [patients]);

  // Fetching Logic
  const fetchAnalytics = async (forceRefresh = false) => {
    if (forceRefresh) {
      setIsRefreshingCache(true);
    } else {
      setLoading(true);
    }
    
    try {
      const params = new URLSearchParams();
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      if (selectedDistrict) params.append('district', selectedDistrict);
      if (selectedDoctor) params.append('doctor', selectedDoctor);
      if (selectedScreeningType) params.append('screeningType', selectedScreeningType);
      if (forceRefresh) params.append('forceRefresh', 'true');

      const res = await fetch(`/api/analytics?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setAnalyticsData(data);
      }
    } catch (err) {
      console.error('Error fetching analytics from backend:', err);
    } finally {
      setLoading(false);
      setIsRefreshingCache(false);
    }
  };

  // Run search on filters change
  useEffect(() => {
    fetchAnalytics();
  }, [startDate, endDate, selectedDistrict, selectedDoctor, selectedScreeningType]);

  // Excel Export Trigger
  const handleExportExcel = () => {
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    if (selectedDistrict) params.append('district', selectedDistrict);
    if (selectedDoctor) params.append('doctor', selectedDoctor);
    if (selectedScreeningType) params.append('screeningType', selectedScreeningType);
    
    window.location.href = `/api/analytics/export?${params.toString()}`;
  };

  // Print PDF Layout trigger
  const handlePrintReport = () => {
    window.print();
  };

  if (loading && !analyticsData) {
    return (
      <div className="bg-white p-12 rounded-2xl border border-gray-100 shadow-sm text-center py-24 space-y-4">
        <RefreshCw className="w-10 h-10 text-blue-500 animate-spin mx-auto" />
        <h4 className="font-bold text-gray-900 text-sm">Сбор и агрегация аналитических данных...</h4>
        <p className="text-xs text-gray-500 max-w-xs mx-auto">Расчет показателей по терапевтическим участкам, врачам и видам обследования в реальном времени.</p>
      </div>
    );
  }

  const metrics = analyticsData?.metrics || {
    totalPatients: 0,
    totalInvitations: 0,
    completedInvitations: 0,
    activeInvitations: 0,
    cancelledInvitations: 0,
    coverageRate: 0,
    conversionRate: 0
  };

  const cacheInfo = analyticsData?.cacheInfo || {
    lastUpdated: new Date().toISOString(),
    nextScheduled: new Date().toISOString(),
    isFromCache: false
  };

  return (
    <div className="space-y-6 print:p-0 print:space-y-4">
      {/* HEADER SECTION WITH FILTER ACTION BAR */}
      <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4 print:hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-gray-900 flex items-center gap-1.5">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              <span>Аналитическая отчётность диспенсаризации</span>
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Мониторинг охвата целевых групп и конверсии информирования населения КМИС
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => fetchAnalytics(true)}
              disabled={isRefreshingCache}
              className="px-3 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-200 hover:border-gray-300 text-gray-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all disabled:opacity-55"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-gray-500 ${isRefreshingCache ? 'animate-spin' : ''}`} />
              <span>Обновить кэш</span>
            </button>

            <button
              onClick={handleExportExcel}
              className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 hover:border-emerald-300 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Экспорт Excel</span>
            </button>

            <button
              onClick={handlePrintReport}
              className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 hover:border-indigo-300 text-indigo-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-600" />
              <span>Печать PDF</span>
            </button>
          </div>
        </div>

        {/* Filters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-3 border-t border-gray-100 text-xs">
          {/* Start Date */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Дата начала:</label>
            <div className="relative">
              <Calendar className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full pl-9 pr-2 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-gray-700"
              />
            </div>
          </div>

          {/* End Date */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Дата конца:</label>
            <div className="relative">
              <Calendar className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full pl-9 pr-2 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-gray-700"
              />
            </div>
          </div>

          {/* District Filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Терап. участок:</label>
            <div className="relative">
              <MapPin className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="w-full pl-9 pr-2 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-gray-700 appearance-none cursor-pointer"
              >
                <option value="">Все участки</option>
                {uniqueDistricts.map(dist => (
                  <option key={dist} value={dist}>{dist}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Doctor Filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Участковый врач:</label>
            <div className="relative">
              <User className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
              <select
                value={selectedDoctor}
                onChange={(e) => setSelectedDoctor(e.target.value)}
                className="w-full pl-9 pr-2 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-gray-700 appearance-none cursor-pointer"
              >
                <option value="">Все врачи</option>
                {uniqueDoctors.map(doc => (
                  <option key={doc} value={doc}>{doc}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Screening Type Filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Вид скрининга:</label>
            <div className="relative">
              <Activity className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
              <select
                value={selectedScreeningType}
                onChange={(e) => setSelectedScreeningType(e.target.value)}
                className="w-full pl-9 pr-2 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-gray-700 appearance-none cursor-pointer"
              >
                <option value="">Все виды скрининга</option>
                {SCREENING_TYPES.map(type => (
                  <option key={type.id} value={type.id}>{type.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Scheduler Cron update alert */}
        <div className="bg-blue-50/50 border border-blue-100 p-3 rounded-xl flex items-center justify-between text-[11px] text-blue-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
            <div>
              <span><b>Автономная синхронизация:</b> Показатели обновляются ежесуточно в 00:00 (cron: <code>0 0 * * *</code>).</span>
              <span className="hidden sm:inline"> Данные кэшированы на сервере.</span>
            </div>
          </div>
          <div className="font-semibold text-right">
            <span>Кэш от: {new Date(cacheInfo.lastUpdated).toLocaleTimeString('ru-RU')} {new Date(cacheInfo.lastUpdated).toLocaleDateString('ru-RU')}</span>
            {cacheInfo.isFromCache && <span className="ml-1.5 bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase">Из кэша</span>}
          </div>
        </div>
      </div>

      {/* PRINT-ONLY HEADER */}
      <div className="hidden print:block border-b-2 border-gray-300 pb-3 mb-4">
        <h2 className="text-xl font-bold text-slate-900 text-center">ОТЧЕТ ПО ЭФФЕКТИВНОСТИ И ОХВАТУ ДИСПОАНСЕРИЗАЦИИ</h2>
        <div className="grid grid-cols-2 text-xs mt-2 text-gray-600">
          <div><b>Выгрузка за период:</b> {startDate} - {endDate}</div>
          <div className="text-right"><b>Дата составления отчёта:</b> {new Date().toLocaleDateString('ru-RU')} {new Date().toLocaleTimeString('ru-RU')}</div>
          <div><b>Участок:</b> {selectedDistrict || 'Все участки'} • <b>Врач:</b> {selectedDoctor || 'Все врачи'}</div>
          <div className="text-right"><b>Источник данных:</b> КМИС Территориального фонда (ТФОМС)</div>
        </div>
      </div>

      {/* METRICS ROW CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Patients */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-start justify-between print:border-gray-200">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Прикреплено в КМИС</span>
            <h3 className="text-3xl font-extrabold text-gray-900 mt-1">{metrics.totalPatients}</h3>
            <p className="text-[11px] text-gray-500 mt-2 flex items-center gap-1">
              <span className="text-emerald-600 font-bold">100%</span>
              <span>пациентов целевой группы</span>
            </p>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl print:bg-gray-100">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Total Invitations */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-start justify-between print:border-gray-200">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Направлений всего</span>
            <h3 className="text-3xl font-extrabold text-gray-900 mt-1">{metrics.totalInvitations}</h3>
            <p className="text-[11px] text-gray-500 mt-2 flex items-center gap-1.5">
              <span className="text-blue-600 font-bold">{metrics.activeInvitations}</span>
              <span>в активной обработке</span>
            </p>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl print:bg-gray-100">
            <MessageSquare className="w-5 h-5" />
          </div>
        </div>

        {/* Coverage Rate */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-start justify-between print:border-gray-200">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Охват целевой группы</span>
            <h3 className="text-3xl font-extrabold text-gray-900 mt-1">{metrics.coverageRate}%</h3>
            <p className="text-[11px] text-gray-500 mt-2 flex items-center gap-1">
              <span className="text-emerald-600 font-bold">Целевой: 85%</span>
              <span>по нормативу Минздрава</span>
            </p>
          </div>
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl print:bg-gray-100">
            <Award className="w-5 h-5" />
          </div>
        </div>

        {/* Conversion Rate */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-start justify-between print:border-gray-200">
          <div>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Конверсия (Явка)</span>
            <h3 className="text-3xl font-extrabold text-gray-900 mt-1">{metrics.conversionRate}%</h3>
            <p className="text-[11px] text-gray-500 mt-2 flex items-center gap-1">
              <span className="text-emerald-600 font-bold">{metrics.completedInvitations} чел.</span>
              <span>прошли исследования</span>
            </p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl print:bg-gray-100">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* MAIN DATA TABLES & BREAKDOWN */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Coverage Breakdown Table */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4 print:border-gray-200">
          <div className="border-b border-gray-100 pb-3">
            <h4 className="text-sm font-bold text-gray-900">1. Охват населения по типам скринингов</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Доля застрахованных граждан, прошедших обследования по регламенту</p>
          </div>

          <div className="space-y-4">
            {analyticsData?.coverageBreakdown?.map((item: any) => (
              <div key={item.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-gray-700">{item.name}</span>
                  <span className="text-gray-500 font-medium">
                    <b>{item.covered}</b> из <b>{item.eligible}</b> чел ({item.percentage}%)
                  </span>
                </div>
                <div className="w-full bg-gray-100 h-3 rounded-full overflow-hidden flex">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${item.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
            {(!analyticsData?.coverageBreakdown || analyticsData.coverageBreakdown.length === 0) && (
              <div className="text-center text-xs text-gray-400 py-6">Нет данных по выбранным критериям</div>
            )}
          </div>
        </div>

        {/* Screening Conversion Breakdown Table */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4 print:border-gray-200">
          <div className="border-b border-gray-100 pb-3">
            <h4 className="text-sm font-bold text-gray-900">2. Эффективность выписанных направлений</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Доля завершенных случаев (конверсия из приглашения в явку)</p>
          </div>

          <div className="space-y-4">
            {analyticsData?.screeningBreakdown?.map((item: any) => (
              <div key={item.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-semibold text-gray-700">
                  <span>{item.name}</span>
                  <span className="text-gray-500 font-medium">
                    Выписано: <b>{item.total}</b> • Пройдено: <b>{item.completed}</b> ({item.conversion}%)
                  </span>
                </div>
                <div className="w-full bg-gray-100 h-3 rounded-full overflow-hidden flex">
                  <div
                    className="bg-gradient-to-r from-emerald-500 to-teal-600 h-full rounded-full transition-all duration-500"
                    style={{ width: `${item.conversion}%` }}
                  ></div>
                </div>
              </div>
            ))}
            {(!analyticsData?.screeningBreakdown || analyticsData.screeningBreakdown.length === 0) && (
              <div className="text-center text-xs text-gray-400 py-6">Нет данных по направлениям</div>
            )}
          </div>
        </div>

        {/* District Breakdown Table */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4 lg:col-span-2 print:border-gray-200">
          <div className="border-b border-gray-100 pb-3">
            <h4 className="text-sm font-bold text-gray-900">3. Аналитика эффективности по терапевтическим участкам</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Показатели вовлечения застрахованного контингента по участкам</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-200 text-gray-400 font-semibold">
                  <th className="py-2.5">Терапевтический участок</th>
                  <th className="py-2.5 text-center">Выписано направлений</th>
                  <th className="py-2.5 text-center">Пройдено скринингов</th>
                  <th className="py-2.5 text-center">Конверсия приглашений</th>
                  <th className="py-2.5 text-center">Целевой контингент</th>
                  <th className="py-2.5 text-center">Всего обследовано</th>
                  <th className="py-2.5 text-right">Общий охват (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {analyticsData?.districtBreakdown?.map((item: any) => (
                  <tr key={item.name} className="hover:bg-gray-50 transition-colors">
                    <td className="py-3 font-semibold text-gray-900 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                      <span>{item.name}</span>
                    </td>
                    <td className="py-3 text-center font-medium text-gray-600">{item.total}</td>
                    <td className="py-3 text-center font-bold text-emerald-700">{item.completed}</td>
                    <td className="py-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                        item.conversion >= 50 ? 'bg-emerald-50 text-emerald-700' : item.conversion >= 25 ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {item.conversion}%
                      </span>
                    </td>
                    <td className="py-3 text-center font-medium text-gray-600">{item.eligible}</td>
                    <td className="py-3 text-center font-bold text-indigo-700">{item.covered}</td>
                    <td className="py-3 text-right">
                      <span className="font-extrabold text-slate-900">{item.coverage}%</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Doctor Breakdown Table */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4 lg:col-span-2 print:border-gray-200">
          <div className="border-b border-gray-100 pb-3">
            <h4 className="text-sm font-bold text-gray-900">4. Аналитика эффективности по участковым врачам</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Индивидуальные рейтинги врачей КМИС по достижению целевых показателей</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-gray-200 text-gray-400 font-semibold">
                  <th className="py-2.5">Участковый терапевт</th>
                  <th className="py-2.5 text-center">Выписано направлений</th>
                  <th className="py-2.5 text-center">Явка (Пройдено)</th>
                  <th className="py-2.5 text-center">Эффективность информирования</th>
                  <th className="py-2.5 text-center">Реестр пациентов (чел)</th>
                  <th className="py-2.5 text-center">Обследовано вовремя</th>
                  <th className="py-2.5 text-right">Уровень охвата (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {analyticsData?.doctorBreakdown?.map((item: any) => (
                  <tr key={item.name} className="hover:bg-gray-50 transition-colors">
                    <td className="py-3 font-semibold text-gray-900 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                      <span>{item.name}</span>
                    </td>
                    <td className="py-3 text-center font-medium text-gray-600">{item.total}</td>
                    <td className="py-3 text-center font-bold text-emerald-700">{item.completed}</td>
                    <td className="py-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                        item.conversion >= 50 ? 'bg-emerald-50 text-emerald-700' : item.conversion >= 25 ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        {item.conversion}%
                      </span>
                    </td>
                    <td className="py-3 text-center font-medium text-gray-600">{item.eligible}</td>
                    <td className="py-3 text-center font-bold text-indigo-700">{item.covered}</td>
                    <td className="py-3 text-right">
                      <span className="font-extrabold text-slate-900">{item.coverage}%</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Daily trend panel */}
        <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4 lg:col-span-2 print:border-gray-200">
          <div className="border-b border-gray-100 pb-3">
            <h4 className="text-sm font-bold text-gray-900">5. Динамика регистраций и завершения обследований по дням</h4>
            <p className="text-[11px] text-gray-500 mt-0.5">Распределение активности по датам выбранного произвольного периода</p>
          </div>

          <div className="space-y-4 pt-2">
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
              {analyticsData?.periodBreakdown?.map((item: any) => (
                <div key={item.period} className="p-3 bg-gray-50 border border-gray-100 rounded-xl space-y-1 text-center hover:shadow-sm transition-all">
                  <div className="text-[10px] text-gray-400 font-bold">
                    {new Date(item.period).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}
                  </div>
                  <div className="flex justify-around items-baseline pt-1">
                    <div>
                      <div className="text-[9px] text-gray-400 block">Выписано</div>
                      <span className="text-xs font-bold text-blue-700">{item.created}</span>
                    </div>
                    <div>
                      <div className="text-[9px] text-gray-400 block font-semibold text-emerald-700">Пройдено</div>
                      <span className="text-xs font-extrabold text-emerald-700">{item.completed}</span>
                    </div>
                  </div>
                </div>
              ))}
              {(!analyticsData?.periodBreakdown || analyticsData.periodBreakdown.length === 0) && (
                <div className="col-span-full text-center text-xs text-gray-400 py-6">В выбранном периоде нет зарегистрированной активности по направлениям</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
