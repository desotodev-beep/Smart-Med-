import React from 'react';
import { KMISUser, KMISRole } from '../types';
import { Shield, User, Clock } from 'lucide-react';

interface RoleHeaderProps {
  currentUser: KMISUser;
  allUsers: KMISUser[];
  onUserChange: (user: KMISUser) => void;
}

export const RoleHeader: React.FC<RoleHeaderProps> = ({
  currentUser,
  allUsers,
  onUserChange,
}) => {
  const handleUserChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selected = allUsers.find(u => u.id === e.target.value);
    if (selected) {
      onUserChange(selected);
    }
  };

  const getRoleBadgeStyle = (role: KMISRole) => {
    switch (role) {
      case 'doctor':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'operator':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'coordinator':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'admin':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'director':
        return 'bg-slate-50 text-slate-700 border-slate-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* App Branding */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-100">
            <span className="font-bold text-lg tracking-wider font-sans">К</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-gray-900 tracking-tight">КМИС: Скрининги</h1>
              <span className="px-2 py-0.5 text-[11px] font-medium bg-blue-50 text-blue-600 rounded-md">Модуль РБ</span>
            </div>
            <p className="text-xs text-gray-400">Управление приглашениями и охватом населения</p>
          </div>
        </div>

        {/* Info & Simulated Time */}
        <div className="flex items-center gap-4 flex-wrap sm:flex-nowrap">
          <div className="hidden lg:flex items-center gap-2 text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg">
            <Clock className="w-3.5 h-3.5 text-gray-400" />
            <span>Системное время: <b>07.07.2026</b></span>
          </div>

          {/* Role selector panel */}
          <div className="flex items-center gap-2 bg-gray-50 p-1.5 rounded-xl border border-gray-200/60 shadow-inner">
            <div className="flex items-center gap-1.5 px-2.5 text-xs text-gray-600">
              <Shield className="w-4 h-4 text-gray-400" />
              <span className="hidden md:inline font-medium">Режим КМИС:</span>
            </div>
            <select
              value={currentUser.id}
              onChange={handleUserChange}
              className="bg-white border border-gray-200 rounded-lg text-xs font-semibold text-gray-700 py-1.5 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer shadow-sm"
              id="role-switcher-select"
            >
              {allUsers.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name} ({user.roleName})
                </option>
              ))}
            </select>

            <span className={`px-2 py-1 text-xs font-semibold rounded-lg border uppercase tracking-wider ${getRoleBadgeStyle(currentUser.role)}`}>
              {currentUser.role}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
