import React, { useState, useEffect } from 'react';
import { Invitation, Patient, PatientQuestionnaire } from '../types';
import { SCREENING_TYPES } from '../mockData';
import { 
  Heart, 
  User, 
  Calendar, 
  Clock, 
  CheckCircle, 
  ShieldAlert, 
  FileText, 
  AlertCircle, 
  ChevronRight, 
  ArrowLeft,
  Activity,
  ClipboardCheck,
  Building,
  HelpCircle
} from 'lucide-react';

interface PatientPortalProps {
  inviteId: string;
  onCompleted?: () => void;
}

export const PatientPortal: React.FC<PatientPortalProps> = ({ inviteId, onCompleted }) => {
  const [invitation, setInvitation] = useState<Invitation | null>(null);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Questionnaire form states
  const [smoker, setSmoker] = useState<'yes' | 'no'>('no');
  const [alcohol, setAlcohol] = useState<'never' | 'occasionally' | 'often'>('never');
  const [chronicDiseases, setChronicDiseases] = useState('');
  const [hasComplaints, setHasComplaints] = useState<'yes' | 'no'>('no');
  const [complaintsDetails, setComplaintsDetails] = useState('');
  const [agreedToScreening, setAgreedToScreening] = useState(false);

  // Scheduling states
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  // Generate date options (next 7 days, excluding Sundays)
  const dateOptions = (() => {
    const list = [];
    const today = new Date();
    for (let i = 1; i <= 8; i++) {
      const nextDate = new Date(today);
      nextDate.setDate(today.getDate() + i);
      if (nextDate.getDay() !== 0) { // Exclude Sunday
        const yyyy = nextDate.getFullYear();
        const mm = String(nextDate.getMonth() + 1).padStart(2, '0');
        const dd = String(nextDate.getDate()).padStart(2, '0');
        const dateStr = `${yyyy}-${mm}-${dd}`;
        const label = nextDate.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'long' });
        list.push({ dateStr, label });
      }
    }
    return list;
  })();

  // Available time slots
  const timeSlots = [
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', 
    '11:00', '11:30', '14:00', '14:30', '15:00', '15:30', '16:00'
  ];

  useEffect(() => {
    const loadPortalData = async () => {
      setLoading(true);
      setError(null);
      try {
        const invRes = await fetch(`/api/invitations`);
        if (!invRes.ok) throw new Error('Ошибка при загрузке направлений');
        const invitationsList: Invitation[] = await invRes.json();
        const foundInv = invitationsList.find(i => i.id === inviteId);
        
        if (!foundInv) {
          setError('Приглашение не найдено или ссылка устарела. Обратитесь в поликлинику.');
          setLoading(false);
          return;
        }

        setInvitation(foundInv);

        // Fetch patient
        const patRes = await fetch(`/api/patients`);
        if (!patRes.ok) throw new Error('Ошибка при загрузке данных пациента');
        const patientsList: Patient[] = await patRes.json();
        const foundPat = patientsList.find(p => p.id === foundInv.patient_id);

        if (foundPat) {
          setPatient(foundPat);
        } else {
          setError('Данные пациента не найдены в системе КМИС.');
        }

        // Initialize form states if already registered previously
        if (foundInv.patient_answers) {
          setSmoker(foundInv.patient_answers.smoker);
          setAlcohol(foundInv.patient_answers.alcohol);
          setChronicDiseases(foundInv.patient_answers.chronicDiseases);
          setHasComplaints(foundInv.patient_answers.hasComplaints);
          setComplaintsDetails(foundInv.patient_answers.complaintsDetails || '');
          setAgreedToScreening(foundInv.patient_answers.agreedToScreening);
        }
        if (foundInv.appointment_date) setSelectedDate(foundInv.appointment_date);
        if (foundInv.appointment_time) setSelectedTime(foundInv.appointment_time);

      } catch (err: any) {
        setError(err.message || 'Ошибка сети при обращении к серверу КМИС');
      } finally {
        setLoading(false);
      }
    };

    if (inviteId) {
      loadPortalData();
    }
  }, [inviteId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!agreedToScreening) {
      setFormError('Пожалуйста, подтвердите согласие на прохождение обследования.');
      return;
    }
    if (!selectedDate || !selectedTime) {
      setFormError('Пожалуйста, выберите дату и время приема.');
      return;
    }
    if (!invitation) return;

    setSubmitting(true);
    const answers: PatientQuestionnaire = {
      smoker,
      alcohol,
      chronicDiseases,
      hasComplaints,
      complaintsDetails: hasComplaints === 'yes' ? complaintsDetails : '',
      agreedToScreening
    };

    try {
      const res = await fetch(`/api/invitations/${invitation.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: 'read', // Change status to 'read' to indicate patient interacted and filled form
          patient_answers: answers,
          appointment_date: selectedDate,
          appointment_time: selectedTime,
          registered_at: new Date().toISOString(),
          changed_by: 'patient'
        })
      });

      if (res.ok) {
        setSubmitted(true);
      } else {
        setFormError('Не удалось отправить форму на сервер КМИС. Попробуйте еще раз.');
      }
    } catch (err) {
      console.error(err);
      setFormError('Ошибка соединения с сервером КМИС.');
    } finally {
      setSubmitting(false);
    }
  };

  const activeScreening = invitation 
    ? SCREENING_TYPES.find(t => t.id === invitation.screening_type) 
    : null;

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-6">
        <div className="bg-white p-8 rounded-2xl shadow-md border border-gray-100 max-w-sm text-center space-y-4">
          <Activity className="w-12 h-12 text-blue-600 animate-pulse mx-auto" />
          <h3 className="font-bold text-gray-900 text-lg">Защищенное соединение КМИС...</h3>
          <p className="text-xs text-gray-500">Авторизация приглашения и подготовка персонального опросника.</p>
        </div>
      </div>
    );
  }

  if (error || !invitation || !patient) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-6">
        <div className="bg-white p-8 rounded-2xl shadow-md border border-red-100 max-w-md text-center space-y-4">
          <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto" />
          <h3 className="font-bold text-gray-900 text-lg">Ошибка входа в систему</h3>
          <p className="text-xs text-gray-500">{error || 'Неизвестная ошибка инициализации портала.'}</p>
          <div className="pt-2">
            <button
              onClick={() => window.location.href = window.location.origin}
              className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors"
            >
              Вернуться в систему КМИС
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
        <div className="bg-white max-w-lg w-full rounded-3xl border border-gray-100 shadow-xl overflow-hidden p-6 sm:p-8 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-gray-900">Вы успешно записаны!</h2>
            <p className="text-xs text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full inline-block font-medium">Регистрация в КМИС подтверждена</p>
          </div>

          {/* Ticket Body */}
          <div className="bg-slate-50 rounded-2xl border border-dashed border-gray-200 p-5 space-y-4">
            <div className="flex justify-between items-center text-xs pb-3 border-b border-gray-200">
              <span className="text-gray-400 font-semibold uppercase tracking-wider">Электронный талон</span>
              <span className="font-mono font-bold text-slate-800">№ KMIS-{Math.floor(10000 + Math.random() * 90000)}</span>
            </div>

            <div className="space-y-3 text-xs text-gray-700">
              <div className="grid grid-cols-3 gap-2">
                <span className="text-gray-400 font-semibold">Пациент:</span>
                <span className="col-span-2 font-bold text-gray-900">{patient.fullName}</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-gray-400 font-semibold">Обследование:</span>
                <span className="col-span-2 font-bold text-blue-700">{activeScreening?.name}</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-gray-400 font-semibold">Дата приема:</span>
                <span className="col-span-2 font-bold text-gray-900">
                  {new Date(selectedDate).toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-gray-400 font-semibold">Время приема:</span>
                <span className="col-span-2 font-extrabold text-indigo-700">{selectedTime}</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <span className="text-gray-400 font-semibold">Адрес кабинета:</span>
                <span className="col-span-2 text-gray-600">
                  {activeScreening?.department || 'Отделение медицинской профилактики'}, Кабинет № {Math.floor(100 + Math.random() * 150)}
                </span>
              </div>
            </div>

            <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100 text-[11px] text-blue-900 space-y-1">
              <span className="font-bold flex items-center gap-1.5 text-blue-800">
                <AlertCircle className="w-3.5 h-3.5" /> Памятка пациенту:
              </span>
              <ul className="list-disc list-inside space-y-0.5 text-blue-750">
                <li>При себе иметь паспорт, полис ОМС и СНИЛС</li>
                <li>Пожалуйста, подойдите за 10 минут до назначенного времени</li>
                {invitation.screening_type === 'glucose_cholesterol' && <li>Рекомендуется сдавать анализы строго натощак</li>}
                {invitation.screening_type === 'mammography' && <li>Исследование проводится с 5 по 12 день менструального цикла</li>}
              </ul>
            </div>
          </div>

          <div className="text-center">
            <p className="text-[10px] text-gray-400">Информация о вашей регистрации была автоматически отправлена вашему участковому терапевту в КМИС.</p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => window.print()}
              className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Распечатать талон</span>
            </button>
            <button
              onClick={() => {
                if (onCompleted) {
                  onCompleted();
                } else {
                  window.location.href = window.location.origin;
                }
              }}
              className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-colors"
            >
              Завершить
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Top bar */}
        <div className="flex justify-between items-center pb-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
              К
            </div>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Пациентский портал КМИС</span>
          </div>
          <button
            onClick={() => {
              if (onCompleted) {
                onCompleted();
              } else {
                window.location.href = window.location.origin;
              }
            }}
            className="text-xs text-gray-500 hover:text-gray-900 font-semibold flex items-center gap-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Назад в Систему</span>
          </button>
        </div>

        {/* Info card banner */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-6 sm:p-8 text-white shadow-lg space-y-4">
          <div className="flex items-center gap-2 text-xs bg-white/10 px-2.5 py-1 rounded-full w-fit font-semibold uppercase tracking-wider">
            <Heart className="w-3.5 h-3.5 text-rose-300 fill-rose-300 shrink-0" />
            <span>Приглашение на медицинский осмотр</span>
          </div>

          <div className="space-y-2">
            <h1 className="text-lg sm:text-xl font-bold">
              Уважаемый(ая) <span className="font-extrabold">{patient.fullName}</span>!
            </h1>
            <p className="text-xs text-blue-100 leading-relaxed max-w-xl">
              Вам показано прохождение планового профилактического обследования: <b className="text-white underline decoration-wavy underline-offset-4">{activeScreening?.name}</b>. 
              Это исследование важно для раннего выявления заболеваний и контроля вашего здоровья. Процедура проводится бесплатно в рамках программы ОМС.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-white/15 text-xs text-blue-50">
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4 text-blue-200 shrink-0" />
              <span>Адрес: {activeScreening?.department || 'Отделение профилактики'}</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-blue-200 shrink-0" />
              <span>Ваш врач: {patient.assignedDoctor || 'Участковый терапевт'}</span>
            </div>
          </div>
        </div>

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-100 shadow-md space-y-6">
          <div className="border-b border-gray-100 pb-4">
            <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-500" />
              <span>Шаг 1. Предварительный медицинский опросник</span>
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">Данные помогут врачу подготовиться к приему и учесть особенности вашего здоровья.</p>
          </div>

          {/* Questionnaire Grid */}
          <div className="space-y-4 text-xs">
            {/* Smoker */}
            <div className="space-y-2">
              <label className="font-bold text-gray-700 block">1. Курите ли вы табак или электронные сигареты?</label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 hover:bg-gray-100 transition-all font-semibold">
                  <input
                    type="radio"
                    name="smoker"
                    value="no"
                    checked={smoker === 'no'}
                    onChange={() => setSmoker('no')}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500/20"
                  />
                  <span>Нет, не курю</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 hover:bg-gray-100 transition-all font-semibold">
                  <input
                    type="radio"
                    name="smoker"
                    value="yes"
                    checked={smoker === 'yes'}
                    onChange={() => setSmoker('yes')}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500/20"
                  />
                  <span>Да, курю</span>
                </label>
              </div>
            </div>

            {/* Alcohol */}
            <div className="space-y-2">
              <label className="font-bold text-gray-700 block">2. Как часто вы употребляете алкогольные напитки?</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 hover:bg-gray-100 transition-all font-semibold">
                  <input
                    type="radio"
                    name="alcohol"
                    value="never"
                    checked={alcohol === 'never'}
                    onChange={() => setAlcohol('never')}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500/20"
                  />
                  <span>Исключительно редко / Никогда</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 hover:bg-gray-100 transition-all font-semibold">
                  <input
                    type="radio"
                    name="alcohol"
                    value="occasionally"
                    checked={alcohol === 'occasionally'}
                    onChange={() => setAlcohol('occasionally')}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500/20"
                  />
                  <span>Умеренно / По праздникам</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 hover:bg-gray-100 transition-all font-semibold">
                  <input
                    type="radio"
                    name="alcohol"
                    value="often"
                    checked={alcohol === 'often'}
                    onChange={() => setAlcohol('often')}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500/20"
                  />
                  <span>Регулярно</span>
                </label>
              </div>
            </div>

            {/* Chronic Diseases */}
            <div className="space-y-1.5">
              <label className="font-bold text-gray-700 block">
                3. Страдаете ли вы хроническими заболеваниями?
              </label>
              <input
                type="text"
                placeholder="Пример: гипертония, сахарный диабет 2 типа, гастрит (оставьте пустым, если нет)"
                value={chronicDiseases}
                onChange={(e) => setChronicDiseases(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
              />
            </div>

            {/* Complaints */}
            <div className="space-y-2">
              <label className="font-bold text-gray-700 block">
                4. Есть ли у вас конкретные жалобы на самочувствие в настоящее время?
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 hover:bg-gray-100 transition-all font-semibold">
                  <input
                    type="radio"
                    name="complaints"
                    value="no"
                    checked={hasComplaints === 'no'}
                    onChange={() => setHasComplaints('no')}
                    className="w-4 h-4 text-blue-600"
                  />
                  <span>Жалоб нет</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 hover:bg-gray-100 transition-all font-semibold">
                  <input
                    type="radio"
                    name="complaints"
                    value="yes"
                    checked={hasComplaints === 'yes'}
                    onChange={() => setHasComplaints('yes')}
                    className="w-4 h-4 text-blue-600"
                  />
                  <span>Имеются жалобы</span>
                </label>
              </div>

              {hasComplaints === 'yes' && (
                <div className="pt-2 animate-fadeIn">
                  <textarea
                    placeholder="Кратко опишите, что вас беспокоит (боли, одышка, быстрая утомляемость и т.д.)..."
                    value={complaintsDetails}
                    onChange={(e) => setComplaintsDetails(e.target.value)}
                    required={hasComplaints === 'yes'}
                    rows={3}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="border-b border-gray-100 pb-4 pt-2">
            <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-500" />
              <span>Шаг 2. Запись на обследование</span>
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">Выберите свободные дату и время для посещения кабинета скрининга.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Date Select */}
            <div className="space-y-1.5">
              <label className="font-bold text-gray-700 block">Выберите день приема:</label>
              <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto border border-gray-150 p-2 rounded-xl bg-gray-50">
                {dateOptions.map(opt => (
                  <label
                    key={opt.dateStr}
                    className={`flex items-center justify-between px-3 py-2 border rounded-lg cursor-pointer transition-all ${
                      selectedDate === opt.dateStr 
                        ? 'bg-blue-600 border-blue-600 text-white font-bold' 
                        : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100 font-medium'
                    }`}
                  >
                    <span className="capitalize">{opt.label}</span>
                    <input
                      type="radio"
                      name="appointmentDate"
                      value={opt.dateStr}
                      checked={selectedDate === opt.dateStr}
                      onChange={() => setSelectedDate(opt.dateStr)}
                      className="sr-only"
                    />
                    {selectedDate === opt.dateStr && <CheckCircle className="w-4 h-4 text-white" />}
                  </label>
                ))}
              </div>
            </div>

            {/* Time Select */}
            <div className="space-y-1.5">
              <label className="font-bold text-gray-700 block">Выберите время приема:</label>
              <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto border border-gray-150 p-2 rounded-xl bg-gray-50">
                {timeSlots.map(time => (
                  <label
                    key={time}
                    className={`flex items-center justify-center py-2.5 border rounded-lg cursor-pointer transition-all font-mono text-center font-bold ${
                      selectedTime === time 
                        ? 'bg-indigo-600 border-indigo-600 text-white' 
                        : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <span>{time}</span>
                    <input
                      type="radio"
                      name="appointmentTime"
                      value={time}
                      checked={selectedTime === time}
                      onChange={() => setSelectedTime(time)}
                      className="sr-only"
                    />
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Consent Checkbox */}
          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-xs">
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={agreedToScreening}
                onChange={(e) => setAgreedToScreening(e.target.checked)}
                className="w-4 h-4 text-blue-600 focus:ring-blue-500/20 border-gray-300 rounded mt-0.5 cursor-pointer"
                required
              />
              <span className="text-gray-500 font-medium leading-relaxed">
                Я подтверждаю свое добровольное согласие на прохождение диспансеризации и профилактического медицинского осмотра в соответствии с <b className="text-gray-700">ФЗ РФ №323 «Об основах охраны здоровья граждан»</b>. Я подтверждаю достоверность предоставленных сведений.
              </span>
            </label>
          </div>

          {/* Action buttons */}
          {formError && (
            <div className="p-3 bg-red-50 border border-red-150 rounded-2xl flex items-start gap-2 text-rose-800 text-[11px] font-semibold animate-pulse">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500 mt-0.5" />
              <span>{formError}</span>
            </div>
          )}

          <div className="pt-4 flex flex-col sm:flex-row gap-3">
            <button
              type="submit"
              disabled={submitting || !agreedToScreening || !selectedDate || !selectedTime}
              className="flex-1 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl text-xs transition-colors shadow-md hover:shadow-lg flex items-center justify-center gap-2 disabled:opacity-45 disabled:hover:bg-blue-600 disabled:shadow-none cursor-pointer"
            >
              {submitting ? (
                <>
                  <Activity className="w-4 h-4 animate-spin" />
                  <span>Регистрация в КМИС...</span>
                </>
              ) : (
                <>
                  <ClipboardCheck className="w-4 h-4" />
                  <span>Подтвердить запись на обследование</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
