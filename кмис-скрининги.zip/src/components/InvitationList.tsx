import React, { useState, useMemo } from 'react';
import { Invitation, Patient, MessageTemplate, InvitationStatus, DeliveryChannel, ScreeningType } from '../types';
import { USERS, SCREENING_TYPES, INITIAL_TEMPLATES } from '../mockData';
import { Search, Filter, Shield, Eye, Calendar, MapPin, CheckCircle, XCircle, Send, Radio, UserCheck, MessageSquare, ClipboardList, Info, Link, Copy, ExternalLink, Clock } from 'lucide-react';

interface InvitationListProps {
  invitations: Invitation[];
  patients: Patient[];
  templates: MessageTemplate[];
  onUpdateStatus: (invitationId: string, newStatus: InvitationStatus, userId: string, extraData?: { reason?: string; serviceId?: string }) => void;
  onRescheduleInvitation?: (invitationId: string, newDueDate: string, reason: string, userId: string) => void;
  currentUserRole: string;
  currentUserId: string;
  onSendInvitation?: (invitationId: string, customChannels?: DeliveryChannel[]) => Promise<any>;
  globalChannelPriority?: DeliveryChannel[];
}

export const InvitationList: React.FC<InvitationListProps> = ({
  invitations,
  patients,
  templates,
  onUpdateStatus,
  onRescheduleInvitation,
  currentUserRole,
  currentUserId,
  onSendInvitation,
  globalChannelPriority = ['push', 'messenger', 'sms'],
}) => {
  // Filters & search state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [screeningFilter, setScreeningFilter] = useState<string>('all');
  const [channelFilter, setChannelFilter] = useState<string>('all');

  // Selected invitation for detail drawer
  const [selectedInviteId, setSelectedInviteId] = useState<string | null>(null);

  // Status updating form state
  const [serviceIdInput, setServiceIdInput] = useState('');
  const [cancelReasonInput, setCancelReasonInput] = useState('');
  const [rescheduleDateInput, setRescheduleDateInput] = useState('');
  const [rescheduleReasonInput, setRescheduleReasonInput] = useState('');
  const [statusAction, setStatusAction] = useState<'none' | 'complete' | 'cancel' | 'reschedule'>('none');

  // Copy link helper states
  const [copiedInviteId, setCopiedInviteId] = useState<string | null>(null);
  const [copiedDetail, setCopiedDetail] = useState(false);

  // Helpers
  const getPatient = (patientId: string) => patients.find(p => p.id === patientId);
  const getScreeningType = (typeId: string) => SCREENING_TYPES.find(t => t.id === typeId);

  const calculateAge = (birthDateStr: string) => {
    const birthDate = new Date(birthDateStr);
    const today = new Date('2026-07-07');
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  // Compile template text based on patient & screening type
  const compileTemplate = (channel: DeliveryChannel, patient: Patient, screening: ScreeningType, dueDate: string) => {
    const template = templates.find(t => t.channel === channel);
    if (!template) return '';

    let text = template.text_with_placeholders;
    text = text.replace(/{ФИО}/g, patient.fullName);
    text = text.replace(/{скрининг}/g, screening.name);
    text = text.replace(/{кабинет}/g, {
      fluorography: 'Кабинет лучевой диагностики №104',
      mammography: 'Кабинет маммографии №205',
      colonoscopy: 'Кабинет эндоскопии №308',
      glucose_cholesterol: 'Процедурный кабинет №12',
      cytology: 'Смотровая №4',
    }[screening.id] || 'Кабинет профилактики №10');
    text = text.replace(/{адрес}/g, 'ГБУЗ "Городская поликлиника №1", ул. Ленина, д. 45');
    text = text.replace(/{дата}/g, new Date(dueDate).toLocaleDateString('ru-RU'));

    return text;
  };

  // Filter list
  const filteredInvitations = useMemo(() => {
    return [...invitations].reverse().filter(inv => {
      const patient = getPatient(inv.patient_id);
      const screening = getScreeningType(inv.screening_type);

      const matchesSearch = patient
        ? patient.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          patient.phone.includes(searchQuery)
        : false;

      const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;
      const matchesScreening = screeningFilter === 'all' || inv.screening_type === screeningFilter;
      const matchesChannel = channelFilter === 'all' || inv.channels.includes(channelFilter as DeliveryChannel);

      return matchesSearch && matchesStatus && matchesScreening && matchesChannel;
    });
  }, [invitations, searchQuery, statusFilter, screeningFilter, channelFilter, patients]);

  const selectedInvite = useMemo(() => {
    return invitations.find(i => i.id === selectedInviteId) || null;
  }, [invitations, selectedInviteId]);

  const [previewChannel, setPreviewChannel] = useState<DeliveryChannel>('sms');
  const [activeSendChannels, setActiveSendChannels] = useState<DeliveryChannel[]>([]);
  const [isSending, setIsSending] = useState(false);

  React.useEffect(() => {
    if (selectedInvite) {
      setPreviewChannel(selectedInvite.channels[0] || 'sms');
      setRescheduleDateInput(selectedInvite.due_date);
      
      const base = selectedInvite.channels.length > 0 ? selectedInvite.channels : globalChannelPriority;
      const sorted = [...globalChannelPriority].filter(ch => base.includes(ch));
      setActiveSendChannels(sorted.length > 0 ? sorted : globalChannelPriority);
    }
  }, [selectedInviteId, selectedInvite, globalChannelPriority]);

  const getStatusBadge = (inv: Invitation) => {
    switch (inv.status) {
      case 'created':
        return <span className="px-2 py-1 text-[11px] font-bold bg-slate-100 text-slate-700 rounded-md border border-slate-200">Создано</span>;
      case 'sent':
        return <span className="px-2 py-1 text-[11px] font-bold bg-blue-50 text-blue-700 rounded-md border border-blue-200">Отправлено</span>;
      case 'delivered':
        return <span className="px-2 py-1 text-[11px] font-bold bg-emerald-50 text-emerald-700 rounded-md border border-emerald-200">Доставлено</span>;
      case 'read':
        if (inv.patient_answers) {
          return <span className="px-2 py-1 text-[11px] font-bold bg-indigo-600 text-white rounded-md border border-indigo-700">Записан 📅</span>;
        }
        return <span className="px-2 py-1 text-[11px] font-bold bg-indigo-50 text-indigo-700 rounded-md border border-indigo-200">Прочитано</span>;
      case 'completed':
        return <span className="px-2 py-1 text-[11px] font-bold bg-emerald-600 text-white rounded-md border border-emerald-700">Пройден ✅</span>;
      case 'cancelled':
        return <span className="px-2 py-1 text-[11px] font-bold bg-rose-50 text-rose-700 rounded-md border border-rose-200">Отменено</span>;
      case 'not_completed':
        return <span className="px-2 py-1 text-[11px] font-bold bg-amber-50 text-amber-700 rounded-md border border-amber-200">Не пройден</span>;
      default:
        return <span className="px-2 py-1 text-[11px] font-bold bg-gray-100 text-gray-700 rounded-md">{inv.status}</span>;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'Пройден';
      case 'created': return 'Создано';
      case 'sent': return 'Отправлено';
      case 'delivered': return 'Доставлено';
      case 'read': return 'Прочитано';
      case 'cancelled': return 'Отменено';
      case 'not_completed': return 'Не пройден';
      default: return status;
    }
  };

  const getUserName = (userId: string) => {
    if (userId === 'system') return 'Системный робот КМИС';
    const user = USERS.find(u => u.id === userId);
    return user ? `${user.name} (${user.roleName})` : userId;
  };

  const handleUpdateStatusDirect = (status: InvitationStatus) => {
    if (!selectedInviteId) return;

    if (status === 'completed') {
      setStatusAction('complete');
      setServiceIdInput(`srv-${Math.floor(1000 + Math.random() * 9000)}`);
      return;
    }

    if (status === 'cancelled') {
      setStatusAction('cancel');
      setCancelReasonInput('');
      return;
    }

    onUpdateStatus(selectedInviteId, status, currentUserId);
  };

  const submitCompleteAction = () => {
    if (!selectedInviteId || !serviceIdInput.trim()) return;
    onUpdateStatus(selectedInviteId, 'completed', currentUserId, {
      serviceId: serviceIdInput.trim()
    });
    setStatusAction('none');
  };

  const submitCancelAction = () => {
    if (!selectedInviteId || !cancelReasonInput.trim()) return;
    onUpdateStatus(selectedInviteId, 'cancelled', currentUserId, {
      reason: cancelReasonInput.trim()
    });
    setStatusAction('none');
  };

  const submitRescheduleAction = () => {
    if (!selectedInviteId || !rescheduleDateInput || !rescheduleReasonInput.trim() || !onRescheduleInvitation) return;
    onRescheduleInvitation(selectedInviteId, rescheduleDateInput, rescheduleReasonInput.trim(), currentUserId);
    setStatusAction('none');
    setRescheduleReasonInput('');
  };

  const isDirector = currentUserRole === 'director';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* LEFT 2 COLUMNS: LOG & FILTERS */}
      <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-5">
        <div>
          <h4 className="text-base font-bold text-gray-900">Журнал скрининговых направлений</h4>
          <p className="text-xs text-gray-500 mt-0.5">Оперативный учёт, рассылка и трекинг статусов информирования</p>
        </div>

        {/* Filter Toolbar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-gray-50 p-4 rounded-xl border border-gray-100">
          {/* Search */}
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="ФИО пациента, телефон..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500/80 transition-all"
              id="invitation-search"
            />
          </div>

          {/* Status filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/10"
              id="status-filter-select"
            >
              <option value="all">Все статусы</option>
              <option value="created">Создано</option>
              <option value="sent">Отправлено</option>
              <option value="delivered">Доставлено</option>
              <option value="read">Прочитано</option>
              <option value="completed">Пройден ✅</option>
              <option value="cancelled">Отменено</option>
              <option value="not_completed">Не пройден</option>
            </select>
          </div>

          {/* Screening type filter */}
          <div>
            <select
              value={screeningFilter}
              onChange={(e) => setScreeningFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/10"
              id="screening-filter-select"
            >
              <option value="all">Все исследования</option>
              {SCREENING_TYPES.map(type => (
                <option key={type.id} value={type.id}>{type.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Channels filter quick-badges */}
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Filter className="w-3.5 h-3.5" />
          <span>Канал:</span>
          {['all', 'sms', 'push', 'messenger'].map(ch => (
            <button
              key={ch}
              onClick={() => setChannelFilter(ch)}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors border ${
                channelFilter === ch
                  ? 'bg-blue-600 border-blue-600 text-white'
                  : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-600'
              }`}
            >
              {ch === 'all' ? 'Все' : ch === 'sms' ? 'SMS' : ch === 'push' ? 'Push' : 'Messenger'}
            </button>
          ))}
        </div>

        {/* Invitations Table */}
        <div className="overflow-x-auto border border-gray-100 rounded-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                <th className="py-3 px-4">Пациент</th>
                <th className="py-3 px-4">Скрининг</th>
                <th className="py-3 px-4">Каналы</th>
                <th className="py-3 px-4">Статус</th>
                <th className="py-3 px-4">Срок прохождения</th>
                <th className="py-3 px-4 text-right">Ссылка / Детали</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-xs">
              {filteredInvitations.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 px-4 text-center text-gray-400">Назначения по выбранным критериям не найдены</td>
                </tr>
              ) : (
                filteredInvitations.map(inv => {
                  const patient = getPatient(inv.patient_id);
                  const screening = getScreeningType(inv.screening_type);
                  if (!patient || !screening) return null;

                  return (
                    <tr
                      key={inv.id}
                      onClick={() => {
                        setSelectedInviteId(inv.id);
                        setStatusAction('none');
                      }}
                      className={`cursor-pointer transition-colors hover:bg-gray-50/70 ${
                        selectedInviteId === inv.id ? 'bg-blue-50/40 font-medium' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="font-semibold text-gray-900">{patient.fullName}</div>
                        <div className="text-[10px] text-gray-400">{calculateAge(patient.birthDate)} лет • {patient.phone}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-gray-700">{screening.name}</div>
                        <div className="text-[10px] text-gray-400">{screening.department}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-1.5">
                          {inv.channels.map(ch => (
                            <span key={ch} className="px-1.5 py-0.5 bg-gray-50 text-gray-600 rounded text-[9px] font-semibold border border-gray-100 uppercase">
                              {ch}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {getStatusBadge(inv)}
                      </td>
                      <td className="py-3 px-4 text-gray-600 font-medium">
                        {new Date(inv.due_date).toLocaleDateString('ru-RU')}
                      </td>
                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              const patientUrl = `${window.location.origin}?invite=${inv.id}`;
                              navigator.clipboard.writeText(patientUrl);
                              setCopiedInviteId(inv.id);
                              setTimeout(() => setCopiedInviteId(null), 2000);
                            }}
                            className={`p-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-all ${
                              copiedInviteId === inv.id
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-white text-blue-600 border-blue-100 hover:bg-blue-50 hover:text-blue-700'
                            }`}
                            title="Копировать персональную ссылку пациента"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span className="hidden md:inline text-[10px]">
                              {copiedInviteId === inv.id ? 'Скопировано!' : 'Копировать'}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setSelectedInviteId(inv.id);
                              setStatusAction('none');
                            }}
                            className="p-1.5 bg-gray-50 text-gray-500 hover:bg-gray-100 hover:text-gray-700 border border-gray-200 rounded-lg transition-colors"
                            title="Посмотреть детали"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* RIGHT COLUMN: SELECTED INVITATION CONTROL CENTER */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-6">
        <div>
          <h4 className="text-base font-bold text-gray-900">Информационная карта назначения</h4>
          <p className="text-xs text-gray-500 mt-0.5">Управление жизненным циклом и детальный аудит статуса</p>
        </div>

        {!selectedInvite ? (
          <div className="bg-gray-50 rounded-2xl p-8 border border-dashed border-gray-200 text-center space-y-3">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mx-auto">
              <ClipboardList className="w-6 h-6" />
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">Выберите приглашение из журнала слева, чтобы открыть карту информирования, просмотреть историю статусов, проверить шаблон отправляемого сообщения и внести изменения.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Quick Header */}
            <div className="space-y-2 pb-4 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{selectedInvite.id}</span>
                {getStatusBadge(selectedInvite)}
              </div>

              {(() => {
                const pat = getPatient(selectedInvite.patient_id);
                const scr = getScreeningType(selectedInvite.screening_type);
                if (!pat || !scr) return null;

                return (
                  <div className="space-y-1">
                    <h5 className="text-sm font-bold text-gray-900">{pat.fullName}</h5>
                    <p className="text-xs text-gray-500">{scr.name}</p>
                    <div className="text-[10px] text-gray-400 flex flex-wrap gap-2 pt-1.5">
                      <span className="bg-gray-100 px-1.5 py-0.5 rounded">Д-группа: <b>{pat.dispensaryGroup}</b></span>
                      <span className="bg-gray-100 px-1.5 py-0.5 rounded">МКБ: <b>{pat.diagnosis}</b></span>
                      <span className="bg-gray-100 px-1.5 py-0.5 rounded">Тел: <b>{pat.phone}</b></span>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* PATIENT PORTAL LINK & QUESTIONNAIRE RESULTS */}
            {(() => {
              const patientUrl = `${window.location.origin}?invite=${selectedInvite.id}`;

              const handleCopy = () => {
                navigator.clipboard.writeText(patientUrl);
                setCopiedDetail(true);
                setTimeout(() => setCopiedDetail(false), 2500);
              };

              return (
                <div className="space-y-4 pt-1 border-b border-gray-100 pb-4">
                  {/* Copy Link Section */}
                  <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-3.5 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Link className="w-4 h-4 text-blue-600" />
                        <span className="text-xs font-bold text-slate-800">Индивидуальная ссылка пациента</span>
                      </div>
                      <span className="text-[9px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold uppercase">Опрос + Слот</span>
                    </div>

                    <p className="text-[11px] text-gray-500 leading-relaxed">
                      Пациент заполнит опросник здоровья КМИС и выберет дату и время приема:
                    </p>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        readOnly
                        value={patientUrl}
                        className="flex-1 text-[10px] px-2.5 py-1.5 bg-white border border-gray-200 rounded-lg text-gray-500 font-mono select-all focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={handleCopy}
                        className="px-2.5 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg flex items-center gap-1 transition-colors text-xs font-semibold shrink-0"
                      >
                        <Copy className="w-3.5 h-3.5 text-gray-500" />
                        <span>{copiedDetail ? 'Коп.' : 'Копировать'}</span>
                      </button>
                    </div>

                    <div className="flex gap-2 pt-1">
                      <a
                        href={patientUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex-1 py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-center font-bold text-[10px] flex items-center justify-center gap-1 transition-colors"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>Открыть опросник (симуляция)</span>
                      </a>
                    </div>
                  </div>

                  {/* Questionnaire Answers Display */}
                  {selectedInvite.patient_answers ? (
                    <div className="bg-emerald-50/40 border border-emerald-150 rounded-xl p-3.5 space-y-3">
                      <div className="flex items-center justify-between border-b border-emerald-100 pb-1.5">
                        <div className="flex items-center gap-1.5">
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          <span className="text-xs font-bold text-emerald-950">Пациент записан на прием</span>
                        </div>
                        <span className="text-[9px] text-emerald-700 font-medium font-mono">
                          {selectedInvite.registered_at ? new Date(selectedInvite.registered_at).toLocaleDateString('ru-RU') : ''}
                        </span>
                      </div>

                      {/* Appointment summary */}
                      <div className="bg-white/80 border border-emerald-150 rounded-lg p-2.5 space-y-1 text-xs">
                        <div className="text-[9px] uppercase font-bold text-gray-400">Назначенное время приема:</div>
                        <div className="font-bold text-emerald-900 flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                          <span>
                            {selectedInvite.appointment_date ? new Date(selectedInvite.appointment_date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) : ''}
                          </span>
                          <span className="text-gray-300 mx-1">|</span>
                          <Clock className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{selectedInvite.appointment_time}</span>
                        </div>
                      </div>

                      {/* Questionnaire Answers details */}
                      <div className="space-y-1.5 text-[11px] text-gray-600">
                        <div className="grid grid-cols-2 gap-x-2 py-1 border-b border-gray-100/50">
                          <span className="text-gray-400 font-medium">Статус курения:</span>
                          <span className="font-semibold text-gray-800 text-right">
                            {selectedInvite.patient_answers.smoker === 'yes' ? '🚬 Да, курит' : '✅ Не курит'}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-x-2 py-1 border-b border-gray-100/50">
                          <span className="text-gray-400 font-medium">Употребление алкоголя:</span>
                          <span className="font-semibold text-gray-800 text-right">
                            {selectedInvite.patient_answers.alcohol === 'never' ? 'Никогда / Редко' :
                             selectedInvite.patient_answers.alcohol === 'occasionally' ? 'Умеренно' : 'Регулярно ⚠️'}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-x-2 py-1 border-b border-gray-100/50">
                          <span className="text-gray-400 font-medium">Хронические заболевания:</span>
                          <span className="font-semibold text-gray-800 text-right truncate" title={selectedInvite.patient_answers.chronicDiseases || 'Отсутствуют'}>
                            {selectedInvite.patient_answers.chronicDiseases || 'Не указаны'}
                          </span>
                        </div>

                        <div className="py-1">
                          <div className="text-gray-400 font-medium">Жалобы на самочувствие:</div>
                          <div className="font-semibold text-gray-800 mt-1 bg-white p-2 rounded border border-gray-100 leading-relaxed text-[10px]">
                            {selectedInvite.patient_answers.hasComplaints === 'yes' 
                              ? (selectedInvite.patient_answers.complaintsDetails || 'Есть неспецифические жалобы') 
                              : 'Жалоб на момент опроса нет'}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-slate-50 border border-slate-200 border-dashed rounded-xl p-3 text-center">
                      <p className="text-[10px] text-gray-400">Пациент еще не проходил опросник по ссылке.</p>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* COMPILED MESSAGE TEXT PREVIEW */}
            {(() => {
              const pat = getPatient(selectedInvite.patient_id);
              const scr = getScreeningType(selectedInvite.screening_type);
              if (!pat || !scr) return null;

              return (
                <div className="space-y-2">
                  <h6 className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-blue-500" />
                    <span>Предосмотр текстов оповещений</span>
                  </h6>
                  <div className="grid grid-cols-3 gap-1 bg-gray-50 p-1 rounded-lg border border-gray-150 text-[10px] font-bold text-center">
                    {(['sms', 'push', 'messenger'] as DeliveryChannel[]).map(ch => (
                      <button
                        key={ch}
                        type="button"
                        onClick={() => setPreviewChannel(ch)}
                        className={`py-1 rounded transition-all uppercase ${previewChannel === ch ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-800'}`}
                      >
                        {ch}
                      </button>
                    ))}
                  </div>
                  <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl text-xs text-gray-600 font-mono leading-relaxed relative min-h-[70px]">
                    <span className="absolute bottom-1 right-2 text-[8px] text-gray-400">Предосмотр КМИС</span>
                    {compileTemplate(previewChannel, pat, scr, selectedInvite.due_date)}
                  </div>
                </div>
              );
            })()}

            {/* MULTI-CHANNEL FAILOVER SENDER BOX */}
            {['created', 'sent', 'delivered', 'read'].includes(selectedInvite.status) && (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 shadow-inner">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Send className="w-4 h-4 text-blue-600" />
                    <span className="text-xs font-bold text-slate-800">
                      {selectedInvite.status === 'created' ? 'Умная мультиканальная отправка' : 'Повторный запуск с failover'}
                    </span>
                  </div>
                  <span className="text-[9px] bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-bold uppercase tracking-wide">КМИС-Рассылка</span>
                </div>

                <div className="space-y-1.5">
                  {activeSendChannels.map((ch, idx) => {
                    const pat = getPatient(selectedInvite.patient_id);
                    let isAvailable = true;
                    let availReason = 'Доступен';
                    if (ch === 'sms') {
                      if (!pat?.phone) {
                        isAvailable = false;
                        availReason = 'Нет телефона';
                      } else if (pat.phone.endsWith('9')) {
                        isAvailable = false;
                        availReason = 'Сбой шлюза (Код 404)';
                      }
                    } else if (ch === 'push') {
                      const numericId = parseInt(pat?.id.replace('p', '') || '0');
                      const hasApp = numericId % 2 !== 0;
                      if (!hasApp) {
                        isAvailable = false;
                        availReason = 'Приложение не установлено';
                      }
                    } else if (ch === 'messenger') {
                      const numericId = parseInt(pat?.id.replace('p', '') || '0');
                      const hasMessenger = [1, 2, 5, 6].includes(numericId);
                      if (!hasMessenger) {
                        isAvailable = false;
                        availReason = 'Аккаунт не привязан';
                      }
                    }

                    return (
                      <div key={ch} className="bg-white px-2.5 py-1.5 border border-slate-200 rounded-lg flex items-center justify-between text-[11px]">
                        <div className="flex items-center gap-1.5">
                          <span className="w-4 h-4 rounded-full bg-slate-100 flex items-center justify-center font-bold text-[9px] text-slate-500">{idx + 1}</span>
                          <span className="font-semibold text-slate-700">
                            {ch === 'sms' ? '📳 SMS-канал' : ch === 'push' ? '📲 Push-канал' : '💬 Мессенджер'}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <span className={`text-[9px] font-semibold px-1.5 py-0.2 rounded border ${
                            isAvailable 
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                              : 'bg-amber-50 text-amber-700 border-amber-200'
                          }`}>
                            {availReason}
                          </span>
                          
                          <div className="flex gap-0.5">
                            <button
                              type="button"
                              disabled={idx === 0 || isSending || isDirector}
                              onClick={() => {
                                const next = [...activeSendChannels];
                                const tmp = next[idx];
                                next[idx] = next[idx - 1];
                                next[idx - 1] = tmp;
                                setActiveSendChannels(next);
                              }}
                              className="p-0.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded text-[8px]"
                              title="Выше в очереди"
                            >
                              ▲
                            </button>
                            <button
                              type="button"
                              disabled={idx === activeSendChannels.length - 1 || isSending || isDirector}
                              onClick={() => {
                                const next = [...activeSendChannels];
                                const tmp = next[idx];
                                next[idx] = next[idx + 1];
                                next[idx + 1] = tmp;
                                setActiveSendChannels(next);
                              }}
                              className="p-0.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded text-[8px]"
                              title="Ниже в очереди"
                            >
                              ▼
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {isDirector ? (
                  <div className="text-[10px] text-gray-400 italic">Отправка доступна только координаторам и администраторам.</div>
                ) : (
                  <button
                    type="button"
                    disabled={isSending || activeSendChannels.length === 0}
                    onClick={async () => {
                      if (!onSendInvitation) return;
                      setIsSending(true);
                      await onSendInvitation(selectedInvite.id, activeSendChannels);
                      setIsSending(false);
                    }}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-sm"
                  >
                    {isSending ? (
                      <>
                        <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                        <span>Рассылка по цепочке...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Отправить по цепочке каналов</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            )}

            {/* LIFE CYCLE ACTIONS PANEL */}
            <div className="space-y-3">
              <h6 className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-blue-500" />
                <span>Управление статусом информирования</span>
              </h6>

              {isDirector ? (
                <div className="p-3 bg-gray-50 text-gray-400 border border-gray-200 text-xs rounded-xl flex items-center gap-2">
                  <Shield className="w-4 h-4 shrink-0" />
                  <span>Режим руководителя: изменение статусов заблокировано.</span>
                </div>
              ) : statusAction === 'complete' ? (
                /* Completion fields form */
                <div className="bg-emerald-50/50 border border-emerald-200 p-3.5 rounded-xl space-y-3 text-xs">
                  <div className="font-semibold text-emerald-900 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Регистрация оказания услуги</span>
                  </div>
                  <p className="text-gray-500 text-[11px]">Для закрытия назначения введите ID выполненной услуги из реестра ТФОМС/КМИС:</p>
                  <div className="space-y-1.5">
                    <input
                      type="text"
                      placeholder="Например, srv-9921"
                      value={serviceIdInput}
                      onChange={(e) => setServiceIdInput(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-emerald-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 font-mono"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={submitCompleteAction}
                      disabled={!serviceIdInput.trim()}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold disabled:opacity-50"
                    >
                      Подтвердить
                    </button>
                    <button
                      onClick={() => setStatusAction('none')}
                      className="px-3 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-600 rounded-lg font-medium"
                    >
                      Отмена
                    </button>
                  </div>
                </div>
              ) : statusAction === 'cancel' ? (
                /* Cancel fields form */
                <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-xl space-y-3 text-xs">
                  <div className="font-semibold text-rose-900 flex items-center gap-1.5">
                    <XCircle className="w-4 h-4 text-rose-600" />
                    <span>Отмена назначения скрининга</span>
                  </div>
                  <p className="text-gray-500 text-[11px]">Укажите причину отмены или письменного отказа пациента:</p>
                  <div className="space-y-1.5">
                    <input
                      type="text"
                      placeholder="Отказ, переезд, противопоказания..."
                      value={cancelReasonInput}
                      onChange={(e) => setCancelReasonInput(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-rose-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={submitCancelAction}
                      disabled={!cancelReasonInput.trim()}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold disabled:opacity-50"
                    >
                      Подтвердить отмену
                    </button>
                    <button
                      onClick={() => setStatusAction('none')}
                      className="px-3 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-600 rounded-lg font-medium"
                    >
                      Отмена
                    </button>
                  </div>
                </div>
              ) : statusAction === 'reschedule' ? (
                /* Reschedule fields form */
                <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-xl space-y-3 text-xs">
                  <div className="font-semibold text-amber-900 flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-amber-600" />
                    <span>Перенос даты назначения</span>
                  </div>
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-amber-800 uppercase tracking-wider">Новая дата прохождения:</label>
                    <input
                      type="date"
                      value={rescheduleDateInput}
                      onChange={(e) => setRescheduleDateInput(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-amber-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-amber-800 uppercase tracking-wider">Укажите причину переноса срока:</label>
                    <input
                      type="text"
                      placeholder="Семейные обстоятельства, отпуск, болезнь..."
                      value={rescheduleReasonInput}
                      onChange={(e) => setRescheduleReasonInput(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-amber-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={submitRescheduleAction}
                      disabled={!rescheduleReasonInput.trim() || !rescheduleDateInput}
                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-slate-950 rounded-lg font-bold disabled:opacity-50"
                    >
                      Подтвердить перенос
                    </button>
                    <button
                      onClick={() => setStatusAction('none')}
                      className="px-3 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-600 rounded-lg font-medium"
                    >
                      Отмена
                    </button>
                  </div>
                </div>
              ) : (
                /* Normal status change layout */
                <div className="space-y-2">
                  {/* Status update buttons depending on current status */}
                  <div className="flex flex-wrap gap-2">
                    {['sent', 'created'].includes(selectedInvite.status) && (
                      <button
                        onClick={() => handleUpdateStatusDirect('delivered')}
                        className="py-2 px-3 bg-gray-100 hover:bg-gray-200 border border-gray-200 text-gray-700 rounded-lg font-semibold text-xs transition-colors"
                      >
                        Доставлено
                      </button>
                    )}

                    {['delivered', 'sent', 'created'].includes(selectedInvite.status) && (
                      <button
                        onClick={() => handleUpdateStatusDirect('read')}
                        className="py-2 px-3 bg-indigo-50 hover:bg-indigo-100 border border-indigo-100 text-indigo-700 rounded-lg font-semibold text-xs transition-colors"
                      >
                        Прочитано
                      </button>
                    )}

                    {selectedInvite.status !== 'completed' && selectedInvite.status !== 'cancelled' && (
                      <>
                        <button
                          onClick={() => handleUpdateStatusDirect('completed')}
                          className="flex-1 py-2 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1 transition-colors shadow-sm"
                        >
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Пройден ✅</span>
                        </button>

                        <button
                          onClick={() => setStatusAction('reschedule')}
                          className="py-2 px-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-100 text-amber-700 rounded-lg font-semibold text-xs transition-colors flex items-center gap-1"
                        >
                          <Calendar className="w-3.5 h-3.5" />
                          <span>Перенести срок</span>
                        </button>

                        <button
                          onClick={() => handleUpdateStatusDirect('cancelled')}
                          className="py-2 px-2.5 bg-rose-50 hover:bg-rose-100 border border-rose-100 text-rose-700 rounded-lg font-semibold text-xs transition-colors"
                        >
                          Отменить
                        </button>
                      </>
                    )}
                  </div>

                  {/* Complete/Cancel specific outcomes indicators */}
                  {selectedInvite.status === 'completed' && selectedInvite.linked_service_id && (
                    <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-xs text-emerald-800 flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold">Назначение успешно выполнено</div>
                        <p className="text-[11px] text-emerald-700 mt-0.5">
                          Связано со случаем обслуживания: <code className="font-mono bg-emerald-100 px-1 py-0.5 rounded text-emerald-900">{selectedInvite.linked_service_id}</code>. В медицинскую карту пациента внесена отметка о прохождении скрининга.
                        </p>
                      </div>
                    </div>
                  )}

                  {selectedInvite.status === 'cancelled' && selectedInvite.cancel_or_reschedule_reason && (
                    <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-xs text-rose-800 flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold">Назначение отменено координатором</div>
                        <p className="text-[11px] text-rose-700 mt-0.5">
                          Зарегистрированная причина отмены: <b>{selectedInvite.cancel_or_reschedule_reason}</b>
                        </p>
                      </div>
                    </div>
                  )}

                  {selectedInvite.status !== 'cancelled' && selectedInvite.status !== 'completed' && selectedInvite.cancel_or_reschedule_reason && (
                    <div className="p-3 bg-amber-50 border border-amber-100 rounded-xl text-xs text-amber-800 flex items-start gap-2">
                      <Calendar className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold">Срок прохождения перенесен</div>
                        <p className="text-[11px] text-amber-700 mt-0.5">
                          Зарегистрированная причина переноса срока: <b>{selectedInvite.cancel_or_reschedule_reason}</b> • Срок: {new Date(selectedInvite.due_date).toLocaleDateString('ru-RU')}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* DELIVERY LOGS SECTION */}
            {selectedInvite.delivery_logs && selectedInvite.delivery_logs.length > 0 && (
              <div className="space-y-3 pt-4 border-t border-gray-100">
                <h6 className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                  <ClipboardList className="w-3.5 h-3.5 text-blue-500" />
                  <span>Детализация попыток доставки (Failover Log)</span>
                </h6>

                <div className="space-y-2 text-xs">
                  {selectedInvite.delivery_logs.map((log, idx) => (
                    <div key={idx} className={`p-3 rounded-xl border ${
                      log.status === 'failed' 
                        ? 'bg-rose-50/40 border-rose-100 text-rose-950' 
                        : log.status === 'delivered' 
                          ? 'bg-emerald-50/40 border-emerald-100 text-emerald-950'
                          : 'bg-blue-50/40 border-blue-100 text-blue-950'
                    }`}>
                      <div className="flex justify-between items-center font-bold">
                        <span className="flex items-center gap-1.5 capitalize">
                          {log.channel === 'sms' ? '📳 SMS-канал' : log.channel === 'push' ? '📲 Push-канал' : '💬 Мессенджер'}
                          {log.status === 'failed' ? (
                            <span className="text-[9px] bg-rose-100 text-rose-700 px-1.5 py-0.2 rounded font-bold">Отказ</span>
                          ) : (
                            <span className="text-[9px] bg-emerald-100 text-emerald-700 px-1.5 py-0.2 rounded font-bold">Доставлено</span>
                          )}
                        </span>
                        <span className="text-[9px] font-normal text-gray-400">
                          {new Date(log.timestamp).toLocaleTimeString('ru-RU')}
                        </span>
                      </div>

                      <div className="text-[10px] text-gray-500 mt-1.5 bg-white p-2 border border-gray-100 rounded-lg max-h-20 overflow-y-auto leading-relaxed">
                        <b>Текст: </b>{log.message_text}
                      </div>

                      {log.status === 'failed' && log.error_details && (
                        <div className="text-[10px] text-rose-750 mt-1.5 font-semibold flex items-center gap-1">
                          <span>❌ Причина:</span>
                          <span className="italic">{log.error_details}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* AUDIT LOG TIMELINE */}
            <div className="space-y-3 pt-4 border-t border-gray-100">
              <h6 className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                <ClipboardList className="w-3.5 h-3.5 text-blue-500" />
                <span>История статусов направления</span>
              </h6>

              <div className="relative pl-4 border-l border-gray-200 space-y-4 text-xs">
                {selectedInvite.status_history.map((hist, idx) => (
                  <div key={idx} className="relative space-y-0.5">
                    {/* Circle marker */}
                    <span className="absolute -left-[21px] top-1.5 w-2.5 h-2.5 rounded-full bg-blue-600 border-2 border-white ring-4 ring-gray-50"></span>
                    <div className="flex justify-between font-semibold text-gray-800">
                      <span>{getStatusLabel(hist.status)}</span>
                      <span className="text-[10px] text-gray-400 font-normal">{new Date(hist.timestamp).toLocaleTimeString('ru-RU')} {new Date(hist.timestamp).toLocaleDateString('ru-RU')}</span>
                    </div>
                    <div className="text-[11px] text-gray-500">
                      Инициатор: <span className="font-medium">{getUserName(hist.changed_by)}</span>
                    </div>
                    {hist.reason && (
                      <div className="text-[10px] text-amber-700 italic bg-amber-50 px-2 py-1 rounded mt-1 border border-amber-100">
                        Причина: {hist.reason}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
