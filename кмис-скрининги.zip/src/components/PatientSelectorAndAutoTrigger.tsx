import React, { useState, useMemo } from 'react';
import { Patient, ScreeningCriteria, Invitation, DeliveryChannel, ScreeningType } from '../types';
import { SCREENING_TYPES, INITIAL_CRITERIA } from '../mockData';
import { Search, UserPlus, Zap, Check, AlertCircle, RefreshCw, Sparkles, Filter, AlertTriangle, Calendar, Phone, Link, Copy, ExternalLink, X } from 'lucide-react';

interface PatientSelectorAndAutoTriggerProps {
  patients: Patient[];
  invitations: Invitation[];
  criteria: ScreeningCriteria[];
  onCreateInvitation: (patientId: string, screeningType: string, channels: DeliveryChannel[], dueDate: string, createdBy: string) => Promise<any>;
  currentUserRole: string;
  currentUserId: string;
}

export const PatientSelectorAndAutoTrigger: React.FC<PatientSelectorAndAutoTriggerProps> = ({
  patients,
  invitations,
  criteria,
  onCreateInvitation,
  currentUserRole,
  currentUserId,
}) => {
  // Manual creation form state
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [selectedScreeningId, setSelectedScreeningId] = useState('');
  const [selectedChannels, setSelectedChannels] = useState<DeliveryChannel[]>(['sms']);
  const [dueDate, setDueDate] = useState('2026-08-07');
  const [manualSearch, setManualSearch] = useState('');
  const [warningMessage, setWarningMessage] = useState<string | null>(null);
  
  // Last created invitation to show a prominent copy banner
  const [lastCreatedInvite, setLastCreatedInvite] = useState<any | null>(null);
  const [copiedLastCreated, setCopiedLastCreated] = useState(false);

  // Global search & filters for patients table
  const [patientFilterSearch, setPatientFilterSearch] = useState('');
  const [selectedDispensaryGroup, setSelectedDispensaryGroup] = useState<string>('Все');

  // Candidate generation state
  const [candidates, setCandidates] = useState<{
    patient: Patient;
    criteria: ScreeningCriteria;
    screeningType: ScreeningType;
    reason: string;
    alreadyHasInvite: boolean;
  }[]>([]);
  const [hasRunSelection, setHasRunSelection] = useState(false);

  // Auto list generation filter states
  const [selectedScheduleFilter, setSelectedScheduleFilter] = useState<'all' | 'daily' | 'weekly'>('all');
  const [candidateDoctorFilter, setCandidateDoctorFilter] = useState<string>('');
  const [candidateDistrictFilter, setCandidateDistrictFilter] = useState<string>('');

  // Extract unique doctors and districts for filtering
  const uniqueDoctors = useMemo(() => {
    const doctors = new Set<string>();
    patients.forEach(p => {
      if (p.assignedDoctor) doctors.add(p.assignedDoctor);
    });
    return Array.from(doctors);
  }, [patients]);

  const uniqueDistricts = useMemo(() => {
    const districts = new Set<string>();
    patients.forEach(p => {
      if (p.district) districts.add(p.district);
    });
    return Array.from(districts);
  }, [patients]);

  // Compute final candidates list filtered by doctor and district
  const finalCandidates = useMemo(() => {
    return candidates.filter(cand => {
      const matchesDoctor = !candidateDoctorFilter || cand.patient.assignedDoctor === candidateDoctorFilter;
      const matchesDistrict = !candidateDistrictFilter || cand.patient.district === candidateDistrictFilter;
      return matchesDoctor && matchesDistrict;
    });
  }, [candidates, candidateDoctorFilter, candidateDistrictFilter]);

  // Helper: Calculate age on 2026-07-07
  const calculateAge = (birthDateStr: string) => {
    const birthDate = new Date(birthDateStr);
    const today = new Date('2026-07-07');
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  // Helper: Find active invitation for patient & screening type
  const getActiveInvitation = (patientId: string, screeningType: string) => {
    return invitations.find(
      inv => inv.patient_id === patientId && 
             inv.screening_type === screeningType && 
             !['completed', 'cancelled', 'not_completed'].includes(inv.status)
    );
  };

  // Run the automated eligibility matching engine
  const runSelectionEngine = () => {
    const foundCandidates: typeof candidates = [];

    // Filter rules by schedule if not 'all'
    const filteredRules = selectedScheduleFilter === 'all'
      ? criteria
      : criteria.filter(c => c.schedule === selectedScheduleFilter);

    patients.forEach(patient => {
      const age = calculateAge(patient.birthDate);

      filteredRules.forEach(rule => {
        const type = SCREENING_TYPES.find(t => t.id === rule.screening_type);
        if (!type) return;

        // 1. Age match
        if (age < rule.age_min || age > rule.age_max) return;

        // 2. Diagnosis match
        let diagnosisMatch = false;
        if (rule.diagnosis_pattern === 'Любой') {
          diagnosisMatch = true;
        } else {
          const patterns = rule.diagnosis_pattern.split('|');
          diagnosisMatch = patterns.some(pat => patient.diagnosis.startsWith(pat));
        }
        if (!diagnosisMatch) return;

        // 3. Dispensary group match
        let dispensaryMatch = false;
        if (rule.dispensary_group === 'Любая') {
          dispensaryMatch = true;
        } else {
          const groups = rule.dispensary_group.split('|');
          dispensaryMatch = groups.includes(patient.dispensaryGroup);
        }
        if (!dispensaryMatch) return;

        // 4. Screening history match
        let needsScreening = false;
        const lastScreeningDateStr = patient.lastScreenings[rule.screening_type];
        let reason = '';

        if (!lastScreeningDateStr) {
          needsScreening = true;
          reason = `Скрининг никогда не проводился (целевая группа: возраст ${rule.age_min}-${rule.age_max})`;
        } else {
          const lastDate = new Date(lastScreeningDateStr);
          const currentDate = new Date('2026-07-07');
          const diffTime = Math.abs(currentDate.getTime() - lastDate.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

          if (diffDays >= rule.days_since_last_screening) {
            needsScreening = true;
            reason = `Прошло ${diffDays} дн. с момента последнего скрининга (норматив: ${rule.days_since_last_screening} дн.)`;
          }
        }

        if (needsScreening) {
          // Check if patient already has an active invitation to prevent duplication
          const activeInvite = getActiveInvitation(patient.id, rule.screening_type);

          foundCandidates.push({
            patient,
            criteria: rule,
            screeningType: type,
            reason,
            alreadyHasInvite: !!activeInvite,
          });
        }
      });
    });

    setCandidates(foundCandidates);
    setHasRunSelection(true);
  };

  // CSV Exporter for candidates
  const handleExportCSV = () => {
    if (finalCandidates.length === 0) return;
    
    const headers = [
      'ID Пациента',
      'ФИО',
      'Пол',
      'Дата рождения',
      'Текущий возраст',
      'Участок',
      'Врач',
      'Диагноз МКБ-10',
      'Д-группа',
      'Вид скрининга',
      'Отделение',
      'Причина отбора',
      'Последнее обследование',
      'Направление'
    ];

    const rows = finalCandidates.map(cand => {
      const age = calculateAge(cand.patient.birthDate);
      const lastScrDate = cand.patient.lastScreenings[cand.screeningType.id] 
        ? new Date(cand.patient.lastScreenings[cand.screeningType.id]).toLocaleDateString('ru-RU')
        : 'Никогда';
      const inviteStatus = cand.alreadyHasInvite ? 'Активно' : 'Ожидает отправки';
      
      return [
        cand.patient.id,
        cand.patient.fullName,
        cand.patient.gender,
        cand.patient.birthDate,
        age,
        cand.patient.district || 'Нет',
        cand.patient.assignedDoctor || 'Нет',
        cand.patient.diagnosis,
        cand.patient.dispensaryGroup,
        cand.screeningType.name,
        cand.screeningType.department,
        cand.reason,
        lastScrDate,
        inviteStatus
      ];
    });

    const csvContent = "\uFEFF" + [
      headers.join(','),
      ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `screening_candidates_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle single manual/candidate selection checking for duplicates
  const handleManualSelectPatient = (patientId: string) => {
    setSelectedPatientId(patientId);
    setWarningMessage(null);

    if (patientId && selectedScreeningId) {
      checkDuplicate(patientId, selectedScreeningId);
    }
  };

  const handleManualSelectScreening = (screeningId: string) => {
    setSelectedScreeningId(screeningId);
    setWarningMessage(null);

    if (selectedPatientId && screeningId) {
      checkDuplicate(selectedPatientId, screeningId);
    }
  };

  const checkDuplicate = (patientId: string, screeningId: string) => {
    const activeInvite = getActiveInvitation(patientId, screeningId);
    if (activeInvite) {
      const patient = patients.find(p => p.id === patientId);
      const screening = SCREENING_TYPES.find(s => s.id === screeningId);
      const formattedStatus = {
        created: 'Создано',
        sent: 'Отправлено',
        delivered: 'Доставлено',
        read: 'Прочитано',
      }[activeInvite.status as string] || activeInvite.status;

      setWarningMessage(
        `🚨 ДУБЛИРОВАНИЕ ЗАБЛОКИРОВАНО! У пациента ${patient?.fullName} уже есть активное приглашение на "${screening?.name}" в статусе "${formattedStatus}" от ${new Date(activeInvite.created_at).toLocaleDateString('ru-RU')}. Повторное информирование не требуется.`
      );
      return true;
    } else {
      setWarningMessage(null);
      return false;
    }
  };

  const handleCreateManualInvitation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientId || !selectedScreeningId) return;

    // Last-second duplicate check
    if (checkDuplicate(selectedPatientId, selectedScreeningId)) {
      return;
    }

    setLastCreatedInvite(null);
    setCopiedLastCreated(false);

    const result = await onCreateInvitation(
      selectedPatientId,
      selectedScreeningId,
      selectedChannels,
      dueDate,
      currentUserId
    );

    if (result) {
      setLastCreatedInvite(result);
    }

    // Reset manual form except due date and channels
    setSelectedPatientId('');
    setSelectedScreeningId('');
    setManualSearch('');
    setWarningMessage(null);
  };

  const handleChannelToggle = (channel: DeliveryChannel) => {
    if (selectedChannels.includes(channel)) {
      if (selectedChannels.length > 1) {
        setSelectedChannels(selectedChannels.filter(c => c !== channel));
      }
    } else {
      setSelectedChannels([...selectedChannels, channel]);
    }
  };

  // Batch action for candidates
  const handleBatchGenerate = () => {
    // Filter out those who already have active invitations
    const validCandidates = finalCandidates.filter(c => !c.alreadyHasInvite);
    if (validCandidates.length === 0) return;

    validCandidates.forEach(cand => {
      // 30 days due date default
      onCreateInvitation(
        cand.patient.id,
        cand.screeningType.id,
        ['sms'], // Default auto-generation channel is SMS
        '2026-08-07',
        'system' // Created automatically by the system cron
      );
    });

    // Clear candidates list or refresh selection
    runSelectionEngine();
  };

  const handleGenerateSingleCandidate = (cand: typeof candidates[0]) => {
    onCreateInvitation(
      cand.patient.id,
      cand.screeningType.id,
      ['sms'],
      '2026-08-07',
      currentUserId
    );
    // update list
    setCandidates(prev => prev.map(c => {
      if (c.patient.id === cand.patient.id && c.screeningType.id === cand.screeningType.id) {
        return { ...c, alreadyHasInvite: true };
      }
      return c;
    }));
  };

  // Patients Search Filter
  const filteredPatients = useMemo(() => {
    return patients.filter(p => {
      const matchesSearch = p.fullName.toLowerCase().includes(patientFilterSearch.toLowerCase()) || 
                            p.phone.includes(patientFilterSearch) ||
                            p.diagnosis.toLowerCase().includes(patientFilterSearch.toLowerCase());
      const matchesGroup = selectedDispensaryGroup === 'Все' || p.dispensaryGroup === selectedDispensaryGroup;
      return matchesSearch && matchesGroup;
    });
  }, [patients, patientFilterSearch, selectedDispensaryGroup]);

  // Patients dropdown options filtered by search in form
  const formPatientsDropdown = useMemo(() => {
    return patients.filter(p => 
      p.fullName.toLowerCase().includes(manualSearch.toLowerCase())
    );
  }, [patients, manualSearch]);

  const isDirector = currentUserRole === 'director';

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      {/* COLUMN 1: DIRECT CREATION FORM */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-6">
        <div>
          <div className="flex items-center gap-2">
            <h4 className="text-base font-bold text-gray-900">Регистрация назначения</h4>
            <span className="px-2 py-0.5 text-[10px] bg-indigo-50 text-indigo-600 rounded-md font-bold uppercase tracking-wide">КМИС</span>
          </div>
          <p className="text-xs text-gray-500 mt-0.5">Врачебное назначение скрининга без оформления талона амбулаторного приёма</p>
        </div>

        {/* SUCCESS BANNER WITH QUICK COPY LINK FOR MANUALLY CREATED INVITATION */}
        {lastCreatedInvite && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 space-y-2.5 shadow-sm relative">
            <button
              type="button"
              onClick={() => setLastCreatedInvite(null)}
              className="absolute right-2.5 top-2.5 p-1 text-emerald-600 hover:text-emerald-800 rounded-lg hover:bg-emerald-100/50 transition-colors"
              title="Закрыть уведомление"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
              <span className="text-xs font-bold text-emerald-950">Ссылка успешно сгенерирована!</span>
            </div>

            {(() => {
              const p = patients.find(pat => pat.id === lastCreatedInvite.patient_id);
              const s = SCREENING_TYPES.find(st => st.id === lastCreatedInvite.screening_type);
              const patientUrl = `${window.location.origin}?invite=${lastCreatedInvite.id}`;

              const handleCopyLast = () => {
                navigator.clipboard.writeText(patientUrl);
                setCopiedLastCreated(true);
                setTimeout(() => setCopiedLastCreated(false), 2500);
              };

              return (
                <div className="space-y-2">
                  <div className="text-[11px] text-emerald-850 leading-relaxed">
                    Пациент: <b className="text-emerald-950">{p?.fullName || 'Пациент'}</b><br />
                    Исследование: <span className="font-semibold text-gray-700">{s?.name || 'Скрининг'}</span>
                  </div>

                  <p className="text-[10px] text-gray-500 leading-relaxed">
                    Отправьте эту ссылку пациенту. Он пройдет опросник здоровья и выберет время приема, после чего результаты появятся на платформе:
                  </p>

                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      readOnly
                      value={patientUrl}
                      className="flex-1 text-[10px] px-2 py-1.5 bg-white border border-emerald-150 rounded-lg text-gray-600 font-mono select-all focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleCopyLast}
                      className={`px-2.5 py-1.5 border rounded-lg flex items-center gap-1 transition-all text-xs font-bold shrink-0 ${
                        copiedLastCreated
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-sm'
                          : 'bg-white border-emerald-200 text-emerald-800 hover:bg-emerald-100/30'
                      }`}
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedLastCreated ? 'Скоп.' : 'Копировать'}</span>
                    </button>
                  </div>

                  <div className="pt-0.5">
                    <a
                      href={patientUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-center font-bold text-[10px] flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Открыть кабинет (симуляция)</span>
                    </a>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {isDirector ? (
          <div className="bg-gray-50 border border-gray-200 text-gray-500 p-4 rounded-xl text-xs text-center">
            🔒 Режим просмотра. Добавление назначений доступно врачам, координаторам и администраторам.
          </div>
        ) : (
          <form onSubmit={handleCreateManualInvitation} className="space-y-4">
            {/* Search Patient */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-gray-600" htmlFor="patient-search-input">Выбор пациента</label>
              <div className="relative">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Введите ФИО для быстрого поиска..."
                  value={manualSearch}
                  onChange={(e) => {
                    setManualSearch(e.target.value);
                    setSelectedPatientId('');
                  }}
                  className="w-full text-xs pl-9 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white focus:border-blue-500/80 transition-all"
                  id="patient-search-input"
                />
              </div>

              {/* Show matching patients in selection box if not selected yet */}
              {!selectedPatientId && manualSearch && (
                <div className="max-h-36 overflow-y-auto border border-gray-100 rounded-xl bg-white shadow-lg p-1 space-y-0.5">
                  {formPatientsDropdown.length === 0 ? (
                    <div className="text-[11px] text-gray-400 p-2 text-center">Пациенты не найдены</div>
                  ) : (
                    formPatientsDropdown.map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          handleManualSelectPatient(p.id);
                          setManualSearch(p.fullName);
                        }}
                        className="w-full text-left text-xs px-3 py-2 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors flex justify-between"
                      >
                        <span className="font-medium">{p.fullName}</span>
                        <span className="text-[10px] text-gray-400">({p.dispensaryGroup}, {calculateAge(p.birthDate)} лет)</span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Selected Patient details indicator */}
            {selectedPatientId && (
              <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-3 text-xs space-y-1">
                {(() => {
                  const p = patients.find(pat => pat.id === selectedPatientId);
                  if (!p) return null;
                  return (
                    <>
                      <div className="font-semibold text-blue-900 flex justify-between">
                        <span>{p.fullName}</span>
                        <span className="bg-blue-100 text-blue-800 text-[9px] px-1.5 py-0.5 rounded-md font-bold uppercase">{p.dispensaryGroup}</span>
                      </div>
                      <div className="text-gray-500 flex justify-between">
                        <span>Возраст: {calculateAge(p.birthDate)} лет</span>
                        <span>Диагноз: <b className="text-gray-700">{p.diagnosis}</b></span>
                      </div>
                      <div className="text-[10px] text-gray-400 pt-1 flex items-center gap-1">
                        <Phone className="w-3 h-3" /> {p.phone}
                      </div>
                    </>
                  );
                })()}
              </div>
            )}

            {/* Screening Type */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-gray-600" htmlFor="screening-type-select">Вид скринингового исследования</label>
              <select
                id="screening-type-select"
                value={selectedScreeningId}
                onChange={(e) => handleManualSelectScreening(e.target.value)}
                required
                className="w-full text-xs px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white"
              >
                <option value="">-- Выберите исследование --</option>
                {SCREENING_TYPES.map(type => (
                  <option key={type.id} value={type.id}>{type.name}</option>
                ))}
              </select>
            </div>

            {/* Warning Message for duplicates */}
            {warningMessage && (
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 text-xs text-rose-800 flex gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                <p className="leading-relaxed">{warningMessage}</p>
              </div>
            )}

            {/* Delivery channels */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-gray-600">Каналы информирования</label>
              <div className="grid grid-cols-3 gap-2">
                {(['sms', 'push', 'messenger'] as DeliveryChannel[]).map((ch) => (
                  <button
                    key={ch}
                    type="button"
                    onClick={() => handleChannelToggle(ch)}
                    className={`py-2 px-1 text-[11px] font-semibold border rounded-lg transition-all flex flex-col items-center justify-center gap-1 ${
                      selectedChannels.includes(ch)
                        ? 'bg-blue-600 border-blue-600 text-white shadow-sm'
                        : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <span className="uppercase text-[9px] tracking-wider">{ch === 'sms' ? 'SMS' : ch === 'push' ? 'Push' : 'Viber/WA'}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Due date */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-gray-600" htmlFor="due-date-input">Действительно до (due_date)</label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
                <input
                  type="date"
                  id="due-date-input"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  required
                  className="w-full text-xs pl-9 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white"
                />
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={!!warningMessage || !selectedPatientId || !selectedScreeningId}
              className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5 ${
                !!warningMessage || !selectedPatientId || !selectedScreeningId
                  ? 'bg-gray-100 border border-gray-200 text-gray-400 cursor-not-allowed shadow-none'
                  : 'bg-blue-600 hover:bg-blue-700 text-white hover:shadow-blue-200 shadow-md'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>Создать направление скрининга</span>
            </button>
          </form>
        )}
      </div>

      {/* COLUMN 2 & 3: AUTOMATIC LIST MATCHING ENGINE & PATIENTS REGISTER */}
      <div className="xl:col-span-2 space-y-6">
        {/* AUTOMATIC CRITERIA SELECTION ENGINE */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-base font-bold text-gray-900">Интеллектуальный автоотбор пациентов</h4>
                <span className="px-2 py-0.5 text-[10px] bg-blue-50 text-blue-600 rounded-md font-bold uppercase tracking-wide">Cron</span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">Поиск пациентов по критериям (возраст, ICD-10, интервалы) и генерация приглашений</p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Schedule Select */}
              <div className="flex bg-gray-50 p-1 rounded-xl border border-gray-200 text-xs">
                <button
                  type="button"
                  onClick={() => setSelectedScheduleFilter('all')}
                  className={`px-2.5 py-1.5 rounded-lg font-bold transition-all ${
                    selectedScheduleFilter === 'all'
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  Все правила
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedScheduleFilter('daily')}
                  className={`px-2.5 py-1.5 rounded-lg font-bold transition-all ${
                    selectedScheduleFilter === 'daily'
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  Ежедневно
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedScheduleFilter('weekly')}
                  className={`px-2.5 py-1.5 rounded-lg font-bold transition-all ${
                    selectedScheduleFilter === 'weekly'
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  Еженедельно
                </button>
              </div>

              <button
                type="button"
                onClick={runSelectionEngine}
                className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold rounded-xl shadow-md shadow-blue-100 flex items-center justify-center gap-1.5 transition-all"
              >
                <Zap className="w-4 h-4" />
                <span>Запустить расчет (CRON)</span>
              </button>
            </div>
          </div>

          {/* If criteria not triggered yet */}
          {!hasRunSelection ? (
            <div className="bg-gray-50 rounded-2xl p-8 border border-dashed border-gray-200 text-center space-y-3">
              <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-blue-500 mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-semibold text-gray-700">Готов к запуску периодического отбора</p>
                <p className="text-xs text-gray-400 max-w-md mx-auto">Выберите периодичность расписания (ежедневно или еженедельно) и нажмите кнопку "Запустить расчет (CRON)" выше, чтобы запустить симуляцию системного сканирования КМИС по критериям.</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-blue-50/40 border border-blue-100/80 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-blue-900 font-medium">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>
                    По критериям ({selectedScheduleFilter === 'all' ? 'Все' : selectedScheduleFilter === 'daily' ? 'Ежедневно' : 'Еженедельно'}) найдено: <b>{candidates.length}</b> чел. 
                    {candidateDoctorFilter || candidateDistrictFilter ? ` (отфильтровано: ${finalCandidates.length})` : ''}
                  </span>
                </div>
                {finalCandidates.some(c => !c.alreadyHasInvite) && !isDirector && (
                  <button
                    type="button"
                    onClick={handleBatchGenerate}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-colors shadow-sm self-start sm:self-auto shrink-0"
                  >
                    Запустить рассылку ({finalCandidates.filter(c => !c.alreadyHasInvite).length})
                  </button>
                )}
              </div>

              {/* Filtering and CSV Export panel */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-gray-50 p-4 rounded-xl border border-gray-200">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1" htmlFor="candidate-doctor-filter">Врач</label>
                  <select
                    id="candidate-doctor-filter"
                    value={candidateDoctorFilter}
                    onChange={(e) => setCandidateDoctorFilter(e.target.value)}
                    className="w-full text-xs px-2.5 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
                  >
                    <option value="">Все врачи ({uniqueDoctors.length})</option>
                    {uniqueDoctors.map(doc => (
                      <option key={doc} value={doc}>{doc}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1" htmlFor="candidate-district-filter">Участок</label>
                  <select
                    id="candidate-district-filter"
                    value={candidateDistrictFilter}
                    onChange={(e) => setCandidateDistrictFilter(e.target.value)}
                    className="w-full text-xs px-2.5 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500"
                  >
                    <option value="">Все участки ({uniqueDistricts.length})</option>
                    {uniqueDistricts.map(dist => (
                      <option key={dist} value={dist}>{dist}</option>
                    ))}
                  </select>
                </div>

                <div className="flex items-end">
                  <button
                    type="button"
                    onClick={handleExportCSV}
                    disabled={finalCandidates.length === 0}
                    className="w-full px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Экспорт в CSV ({finalCandidates.length})</span>
                  </button>
                </div>
              </div>

              {/* Candidates table */}
              <div className="overflow-x-auto border border-gray-100 rounded-xl">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-100 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                      <th className="py-3 px-4">Пациент</th>
                      <th className="py-3 px-4">Исследование</th>
                      <th className="py-3 px-4">Причина отбора (Диагноз / Сроки)</th>
                      <th className="py-3 px-4 text-right">Действие</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-xs">
                    {finalCandidates.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-8 px-4 text-center text-gray-400">Ни один пациент не подошел под выбранные критерии и фильтры</td>
                      </tr>
                    ) : (
                      finalCandidates.map((cand, idx) => (
                        <tr key={`${cand.patient.id}-${cand.screeningType.id}-${idx}`} className="hover:bg-gray-50/40">
                          <td className="py-3 px-4">
                            <div className="font-semibold text-gray-900">{cand.patient.fullName}</div>
                            <div className="text-[10px] text-gray-400">{calculateAge(cand.patient.birthDate)} лет, {cand.patient.gender} • {cand.patient.phone}</div>
                            <div className="text-[9px] text-gray-400 mt-0.5 font-medium">
                              🏥 {cand.patient.district || 'Без участка'} • 🩺 {cand.patient.assignedDoctor || 'Без врача'}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-[10px] font-semibold border border-blue-100 inline-block max-w-[150px] truncate" title={cand.screeningType.name}>
                              {cand.screeningType.name}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-gray-600 max-w-[200px]">
                            <div className="line-clamp-2">{cand.reason}</div>
                            <div className="text-[9px] text-gray-400">Д-учет: {cand.patient.dispensaryGroup} | Диагноз: {cand.patient.diagnosis}</div>
                          </td>
                          <td className="py-3 px-4 text-right">
                            {cand.alreadyHasInvite ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-50 text-amber-700 text-[10px] font-bold rounded-lg border border-amber-200">
                                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                                <span>Уже приглашен</span>
                              </span>
                            ) : isDirector ? (
                              <span className="text-[10px] text-gray-400">Режим просмотра</span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleGenerateSingleCandidate(cand)}
                                className="px-2.5 py-1 bg-gray-900 hover:bg-gray-800 text-white text-[10px] font-bold rounded-lg transition-colors shadow-sm"
                              >
                                Пригласить
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* GENERAL PATIENTS DIRECTORY */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="text-base font-bold text-gray-900">Реестр прикрепленного населения</h4>
              <p className="text-xs text-gray-500 mt-0.5">Полный список прикрепленных к МО граждан и история обследований</p>
            </div>

            {/* Quick group filter */}
            <div className="flex items-center gap-1.5 self-start sm:self-auto">
              <span className="text-xs text-gray-500 font-medium">Группа учета:</span>
              <div className="flex bg-gray-100 p-1 rounded-lg border border-gray-200 text-xs">
                {['Все', 'Д1', 'Д2', 'Д3'].map(g => (
                  <button
                    key={g}
                    onClick={() => setSelectedDispensaryGroup(g)}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-colors ${
                      selectedDispensaryGroup === g
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-500 hover:text-gray-800'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Поиск по ФИО, телефону, коду МКБ..."
              value={patientFilterSearch}
              onChange={(e) => setPatientFilterSearch(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:bg-white focus:border-blue-500/80 transition-all"
              id="patient-registry-search"
            />
          </div>

          {/* Table */}
          <div className="overflow-x-auto border border-gray-100 rounded-xl">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  <th className="py-3 px-4">ФИО</th>
                  <th className="py-3 px-4">Данные КМИС</th>
                  <th className="py-3 px-4">Контакты</th>
                  <th className="py-3 px-4">История прохождения</th>
                  <th className="py-3 px-4 text-right">Назначить</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-xs">
                {filteredPatients.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 px-4 text-center text-gray-400">Нет подходящих пациентов в реестре</td>
                  </tr>
                ) : (
                  filteredPatients.map(p => (
                    <tr key={p.id} className="hover:bg-gray-50/40">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-gray-900">{p.fullName}</div>
                        <div className="text-[10px] text-gray-400">Пол: {p.gender} • Возраст: {calculateAge(p.birthDate)} лет ({new Date(p.birthDate).toLocaleDateString('ru-RU')})</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-gray-700">Диагноз: <span className="font-semibold">{p.diagnosis}</span></div>
                        <div className="mt-0.5">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            p.dispensaryGroup === 'Д3' ? 'bg-amber-100 text-amber-800' : p.dispensaryGroup === 'Д2' ? 'bg-blue-100 text-blue-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>Д-учет: {p.dispensaryGroup}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-gray-600">
                        {p.phone}
                      </td>
                      <td className="py-3 px-4">
                        <div className="space-y-3">
                          {/* Пройденные исследования */}
                          <div className="space-y-1 text-[10px]">
                            <div className="font-semibold text-gray-400 uppercase tracking-wider text-[8px] mb-1">Пройденные исследования:</div>
                            {Object.entries(p.lastScreenings).length === 0 ? (
                              <span className="text-gray-400 italic">Нет пройденных</span>
                            ) : (
                              Object.entries(p.lastScreenings).map(([scrId, dateStr]) => {
                                const scrType = SCREENING_TYPES.find(t => t.id === scrId);
                                return (
                                  <div key={scrId} className="flex items-center justify-between gap-2 max-w-[200px]">
                                    <span className="text-gray-500 truncate" title={scrType?.name}>{scrType?.name}:</span>
                                    <span className="font-bold text-gray-700 shrink-0">{new Date(dateStr as string).toLocaleDateString('ru-RU')}</span>
                                  </div>
                                );
                              })
                            )}
                          </div>

                          {/* Список приглашений (Отдельный блок в карте) */}
                          <div className="border-t border-gray-100/80 pt-2 space-y-1 text-[10px]">
                            <div className="font-semibold text-gray-400 uppercase tracking-wider text-[8px] mb-1">Приглашения из БД КМИС:</div>
                            {invitations.filter(inv => inv.patient_id === p.id).length === 0 ? (
                              <span className="text-gray-400 italic">Нет назначений</span>
                            ) : (
                              <div className="space-y-1 max-h-[80px] overflow-y-auto pr-1">
                                {invitations.filter(inv => inv.patient_id === p.id).map(inv => {
                                  const scrType = SCREENING_TYPES.find(t => t.id === inv.screening_type);
                                  return (
                                    <div key={inv.id} className="flex items-center justify-between gap-1.5">
                                      <span className="text-gray-600 truncate max-w-[110px]" title={scrType?.name}>{scrType?.name}</span>
                                      <span className={`px-1 py-0.2 rounded text-[8px] font-bold border shrink-0 ${
                                        inv.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                                        inv.status === 'cancelled' ? 'bg-rose-50 text-rose-700 border-rose-100' :
                                        inv.status === 'created' ? 'bg-gray-100 text-gray-700 border-gray-200' :
                                        'bg-blue-50 text-blue-700 border-blue-100'
                                      }`}>
                                        {inv.status === 'completed' ? 'Пройден' : 
                                         inv.status === 'cancelled' ? 'Отменен' : 
                                         inv.status === 'created' ? 'Создан' : 'Активен'}
                                      </span>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right">
                        {isDirector ? (
                          <span className="text-[10px] text-gray-400">Просмотр</span>
                        ) : (
                          <button
                            onClick={() => {
                              setSelectedPatientId(p.id);
                              setManualSearch(p.fullName);
                              // Scroll manually to form container
                              document.getElementById('patient-search-input')?.focus();
                            }}
                            className="text-blue-600 hover:text-blue-800 font-bold hover:underline text-[11px]"
                          >
                            Выбрать
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
