import { useState, useEffect } from 'react';
import { RoleHeader } from './components/RoleHeader';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { PatientSelectorAndAutoTrigger } from './components/PatientSelectorAndAutoTrigger';
import { InvitationList } from './components/InvitationList';
import { SettingsTemplates } from './components/SettingsTemplates';
import { PatientPortal } from './components/PatientPortal';

import { Patient, Invitation, ScreeningCriteria, MessageTemplate, KMISUser, InvitationStatus, DeliveryChannel } from './types';
import { USERS, INITIAL_PATIENTS, INITIAL_INVITATIONS, INITIAL_CRITERIA, INITIAL_TEMPLATES, SCREENING_TYPES } from './mockData';
import { BarChart3, Users, ClipboardList, Settings, Sparkles, RefreshCw } from 'lucide-react';

export default function App() {
  // Current user role
  const [currentUser, setCurrentUser] = useState<KMISUser>(() => {
    const local = localStorage.getItem('kmis_current_user');
    return local ? JSON.parse(local) : USERS[3]; // Defaults to Coordinator
  });

  // Database lists
  const [patients, setPatients] = useState<Patient[]>(INITIAL_PATIENTS);
  const [invitations, setInvitations] = useState<Invitation[]>(INITIAL_INVITATIONS);
  const [criteria, setCriteria] = useState<ScreeningCriteria[]>(INITIAL_CRITERIA);
  const [templates, setTemplates] = useState<MessageTemplate[]>(INITIAL_TEMPLATES);
  const [channelPriority, setChannelPriority] = useState<DeliveryChannel[]>(['push', 'messenger', 'sms']);

  const [activeTab, setActiveTab] = useState<'analytics' | 'patients' | 'invitations' | 'settings'>('analytics');
  
  // Patient Portal active state
  const [patientInviteId, setPatientInviteId] = useState<string | null>(() => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('invite');
  });

  useEffect(() => {
    const handlePopState = () => {
      const urlParams = new URLSearchParams(window.location.search);
      setPatientInviteId(urlParams.get('invite'));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' | 'warning' } | null>(null);

  // Webhook Simulator State
  const [selectedSimInviteId, setSelectedSimInviteId] = useState('');
  const [simServiceId, setSimServiceId] = useState('');
  const [simIsLoading, setSimIsLoading] = useState(false);
  const [showSimulator, setShowSimulator] = useState(false);

  // Auto-generate service ID on simulator selection change
  useEffect(() => {
    if (selectedSimInviteId) {
      setSimServiceId(`srv-${Math.floor(1000 + Math.random() * 9000)}`);
    }
  }, [selectedSimInviteId]);

  // Set default simulator selection
  useEffect(() => {
    const active = invitations.filter(inv => inv.status !== 'completed' && inv.status !== 'cancelled');
    if (active.length > 0 && !selectedSimInviteId) {
      setSelectedSimInviteId(active[0].id);
    }
  }, [invitations, selectedSimInviteId]);

  // Load data from backend API
  const fetchAllData = async () => {
    try {
      const [resPatients, resInvitations, resCriteria, resTemplates, resPriority] = await Promise.all([
        fetch('/api/patients'),
        fetch('/api/invitations'),
        fetch('/api/criteria'),
        fetch('/api/templates'),
        fetch('/api/channel_priority')
      ]);
      
      if (resPatients.ok) setPatients(await resPatients.json());
      if (resInvitations.ok) setInvitations(await resInvitations.json());
      if (resCriteria.ok) setCriteria(await resCriteria.json());
      if (resTemplates.ok) setTemplates(await resTemplates.json());
      if (resPriority.ok) setChannelPriority(await resPriority.json());
    } catch (err) {
      console.warn('Backend API not reachable, using mockData fallback:', err);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Sync to localStorage for current user only
  useEffect(() => {
    localStorage.setItem('kmis_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  // Helper trigger message
  const triggerNotification = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  // Reset state to initial mock data
  const handleResetData = async () => {
    if (window.confirm('Вы действительно хотите сбросить все измененные данные к исходным?')) {
      try {
        const res = await fetch('/api/reset', { method: 'POST' });
        if (res.ok) {
          triggerNotification('Данные КМИС успешно восстановлены к заводским настройкам на сервере', 'info');
          fetchAllData();
          return;
        }
      } catch (err) {
        console.warn('Failed to reset on server, falling back to local reset:', err);
      }
      
      setPatients(INITIAL_PATIENTS);
      setInvitations(INITIAL_INVITATIONS);
      setCriteria(INITIAL_CRITERIA);
      setTemplates(INITIAL_TEMPLATES);
      
      triggerNotification('Данные КМИС успешно восстановлены в локальном хранилище', 'info');
    }
  };

  // 1. Create manual or automatic invitation
  const handleCreateInvitation = async (
    patientId: string,
    screeningType: string,
    channels: DeliveryChannel[],
    dueDate: string,
    createdBy: string
  ) => {
    const patientName = patients.find(p => p.id === patientId)?.fullName || 'Пациент';
    
    try {
      const res = await fetch('/api/invitations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patient_id: patientId,
          screening_type: screeningType,
          channels,
          due_date: dueDate,
          created_by: createdBy
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.warning === 'duplicate_extended') {
          // If duplicate was found and updated, merge it in state
          setInvitations(prev => prev.map(inv => inv.id === data.invitation.id ? data.invitation : inv));
          triggerNotification(`⚠️ ${data.message}`, 'warning');
          return data.invitation;
        } else {
          setInvitations(prev => [...prev, data]);
          triggerNotification(`Создано назначение скрининга для: ${patientName}`, 'success');
          return data;
        }
      }
    } catch (err) {
      console.warn('Failed to create invitation on server, falling back to local state:', err);
    }

    // Local fallback check
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const localDuplicate = invitations.find(inv => {
      const isSamePatient = inv.patient_id === patientId;
      const isSameType = inv.screening_type === screeningType;
      const isTerminal = inv.status === 'completed' || inv.status === 'cancelled' || inv.status === 'not_completed';
      const invDueDate = new Date(inv.due_date);
      invDueDate.setHours(23, 59, 59, 999);
      const isNotExpired = invDueDate >= today;
      return isSamePatient && isSameType && !isTerminal && isNotExpired;
    });

    if (localDuplicate) {
      const updatedInv: Invitation = {
        ...localDuplicate,
        due_date: dueDate,
        status_history: [
          ...localDuplicate.status_history,
          {
            status: localDuplicate.status,
            timestamp: new Date().toISOString(),
            changed_by: createdBy,
            reason: `Срок действия продлен до ${dueDate} (предотвращение дублирования)`
          }
        ]
      };
      
      const updated = invitations.map(inv => inv.id === localDuplicate.id ? updatedInv : inv);
      setInvitations(updated);
      triggerNotification(`⚠️ Найдено активное направление. Срок продлен до ${dueDate} (локально)`, 'warning');
      return updatedInv;
    }

    // Local fallback creation
    const newInv: Invitation = {
      id: `inv-${Math.floor(100 + Math.random() * 900)}`,
      patient_id: patientId,
      screening_type: screeningType,
      status: 'created',
      channels,
      created_by: createdBy,
      created_at: new Date().toISOString(),
      due_date: dueDate,
      cancel_or_reschedule_reason: null,
      linked_service_id: null,
      status_history: [
        {
          status: 'created',
          timestamp: new Date().toISOString(),
          changed_by: createdBy,
        },
      ],
    };

    const updated = [...invitations, newInv];
    setInvitations(updated);
    triggerNotification(`Создано назначение скрининга для: ${patientName} (локально)`, 'success');
    return newInv;
  };

  // 2. Update existing invitation status
  const handleUpdateStatus = async (
    invitationId: string,
    newStatus: InvitationStatus,
    userId: string,
    extraData?: { reason?: string; serviceId?: string }
  ) => {
    try {
      const res = await fetch(`/api/invitations/${invitationId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: newStatus,
          cancel_or_reschedule_reason: extraData?.reason || null,
          linked_service_id: extraData?.serviceId || null,
          changed_by: userId
        })
      });
      if (res.ok) {
        fetchAllData();
        triggerNotification(`Статус назначения обновлен на «${newStatus === 'completed' ? 'Пройден' : newStatus === 'cancelled' ? 'Отменен' : newStatus}»`, 'info');
        return;
      }
    } catch (err) {
      console.warn('Failed to update invitation on server, falling back to local state:', err);
    }

    // Local fallback
    const updated = invitations.map(inv => {
      if (inv.id === invitationId) {
        const historyItem = {
          status: newStatus,
          timestamp: new Date().toISOString(),
          changed_by: userId,
          reason: extraData?.reason || (newStatus === 'completed' && extraData?.serviceId ? `Связано с кодом услуги ТФОМС: ${extraData.serviceId}` : undefined),
        };

        if (newStatus === 'completed' && extraData?.serviceId) {
          updatePatientScreeningDate(inv.patient_id, inv.screening_type, '2026-07-07');
        }

        return {
          ...inv,
          status: newStatus,
          cancel_or_reschedule_reason: extraData?.reason || null,
          linked_service_id: extraData?.serviceId || null,
          status_history: [...inv.status_history, historyItem],
        };
      }
      return inv;
    });

    setInvitations(updated);
    triggerNotification(`Статус назначения обновлен на «${newStatus === 'completed' ? 'Пройден' : newStatus === 'cancelled' ? 'Отменен' : newStatus}» (локально)`, 'info');
  };

  // 2a. Reschedule existing invitation
  const handleRescheduleInvitation = async (
    invitationId: string,
    newDueDate: string,
    reason: string,
    userId: string
  ) => {
    try {
      const res = await fetch(`/api/invitations/${invitationId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          due_date: newDueDate,
          cancel_or_reschedule_reason: reason,
          changed_by: userId
        })
      });
      if (res.ok) {
        fetchAllData();
        triggerNotification(`Срок действия направления успешно перенесен на ${new Date(newDueDate).toLocaleDateString('ru-RU')}`, 'success');
        return;
      }
    } catch (err) {
      console.warn('Failed to reschedule invitation on server, falling back to local state:', err);
    }

    // Local fallback
    const updated = invitations.map(inv => {
      if (inv.id === invitationId) {
        const historyItem = {
          status: inv.status,
          timestamp: new Date().toISOString(),
          changed_by: userId,
          reason: `Срок прохождения изменен с ${inv.due_date} на ${newDueDate}. Причина: ${reason}`
        };

        return {
          ...inv,
          due_date: newDueDate,
          cancel_or_reschedule_reason: reason,
          status_history: [...inv.status_history, historyItem]
        };
      }
      return inv;
    });

    setInvitations(updated);
    triggerNotification(`Срок действия направления перенесен на ${new Date(newDueDate).toLocaleDateString('ru-RU')} (локально)`, 'success');
  };

  // Update patient last screening (used in local fallback)
  const updatePatientScreeningDate = (patientId: string, screeningType: string, dateStr: string) => {
    const updated = patients.map(p => {
      if (p.id === patientId) {
        return {
          ...p,
          lastScreenings: {
            ...p.lastScreenings,
            [screeningType]: dateStr,
          },
        };
      }
      return p;
    });

    setPatients(updated);
  };

  // Update Criteria rules
  const handleUpdateCriteria = async (updatedCriteria: ScreeningCriteria[]) => {
    try {
      const res = await fetch('/api/criteria', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedCriteria)
      });
      if (res.ok) {
        const saved = await res.json();
        setCriteria(saved.criteria);
        triggerNotification('Критерии автоматического отбора успешно изменены', 'success');
        return;
      }
    } catch (err) {
      console.warn('Failed to update criteria on server, falling back to local state:', err);
    }

    setCriteria(updatedCriteria);
    triggerNotification('Критерии автоматического отбора успешно изменены (локально)', 'success');
  };

  // Update Templates rules
  const handleUpdateTemplates = async (updatedTemplates: MessageTemplate[]) => {
    try {
      const res = await fetch('/api/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedTemplates)
      });
      if (res.ok) {
        const saved = await res.json();
        setTemplates(saved.templates);
        triggerNotification('Тексты шаблонов успешно изменены', 'success');
        return;
      }
    } catch (err) {
      console.warn('Failed to update templates on server, falling back to local state:', err);
    }

    setTemplates(updatedTemplates);
    triggerNotification('Тексты шаблонов успешно изменены (локально)', 'success');
  };

  // Update Channel Priority Order
  const handleUpdateChannelPriority = async (newPriority: DeliveryChannel[]) => {
    try {
      const res = await fetch('/api/channel_priority', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newPriority)
      });
      if (res.ok) {
        const data = await res.json();
        setChannelPriority(data.channel_priority);
        triggerNotification('Приоритет каналов успешно сохранен', 'success');
        return;
      }
    } catch (err) {
      console.warn('Failed to update channel priority on server, falling back to local state:', err);
    }

    setChannelPriority(newPriority);
    triggerNotification('Приоритет каналов успешно сохранен (локально)', 'success');
  };

  // Dispatch invitation using multi-channel delivery sequence with failover
  const handleSendInvitation = async (invitationId: string, customChannels?: DeliveryChannel[]) => {
    try {
      const res = await fetch(`/api/invitations/${invitationId}/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          channels: customChannels,
          changed_by: currentUser.id
        })
      });
      if (res.ok) {
        const data = await res.json();
        fetchAllData();
        if (data.success) {
          triggerNotification(`Приглашение успешно отправлено через ${data.successChannel.toUpperCase()}`, 'success');
        } else {
          triggerNotification(`Все каналы доставки дали сбой при отправке`, 'warning');
        }
        return data;
      }
    } catch (err) {
      console.warn('Failed to send invitation on server:', err);
      triggerNotification('Ошибка сети при отправке приглашения', 'warning');
    }
  };

  // Simulate Webhook service_provided
  const handleSimulateWebhook = async () => {
    if (!selectedSimInviteId) return;
    const invite = invitations.find(i => i.id === selectedSimInviteId);
    if (!invite) return;

    setSimIsLoading(true);
    try {
      const res = await fetch('/api/webhooks/service_provided', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patient_id: invite.patient_id,
          screening_type: invite.screening_type,
          service_id: simServiceId || `srv-${Math.floor(1000 + Math.random() * 9000)}`
        })
      });
      if (res.ok) {
        const data = await res.json();
        triggerNotification(`[ТФОМС Webhook] ${data.message}`, 'success');
        
        // Clear selection to force recalculation of default active invite
        setSelectedSimInviteId('');
        
        // Refresh all data
        fetchAllData();
      } else {
        const errData = await res.json();
        triggerNotification(`[ТФОМС Webhook] Ошибка: ${errData.error}`, 'warning');
      }
    } catch (err) {
      console.error(err);
      triggerNotification('[ТФОМС Webhook] Сетевая ошибка при отправке события', 'warning');
    } finally {
      setSimIsLoading(false);
    }
  };

  // If we are in Patient Portal mode, render it instead of the dashboard
  if (patientInviteId) {
    return (
      <PatientPortal
        inviteId={patientInviteId}
        onCompleted={() => {
          window.history.pushState({}, '', window.location.origin);
          setPatientInviteId(null);
          fetchAllData();
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased flex flex-col justify-between">
      <div>
        {/* Role Switching Header */}
        <RoleHeader
          currentUser={currentUser}
          allUsers={USERS}
          onUserChange={setCurrentUser}
        />

        {/* Global Floating Notifications Banner */}
        {notification && (
          <div className="fixed bottom-6 right-6 z-50 animate-bounce">
            <div className={`p-4 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-2.5 max-w-sm ${
              notification.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' :
              notification.type === 'warning' ? 'bg-rose-50 border-rose-200 text-rose-800' :
              'bg-blue-50 border-blue-200 text-blue-800'
            }`}>
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>{notification.message}</span>
            </div>
          </div>
        )}

        {/* Main Workspace Layout */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
          {/* Inner Navigation tabs */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-gray-200 pb-3">
            <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200 w-full sm:w-auto">
              {/* Tab 1 */}
              <button
                onClick={() => setActiveTab('analytics')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  activeTab === 'analytics'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-blue-600" />
                <span>Аналитика охвата</span>
              </button>

              {/* Tab 2 */}
              <button
                onClick={() => setActiveTab('patients')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  activeTab === 'patients'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <Users className="w-4 h-4 text-indigo-600" />
                <span>Пациенты и отбор</span>
              </button>

              {/* Tab 3 */}
              <button
                onClick={() => setActiveTab('invitations')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  activeTab === 'invitations'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <ClipboardList className="w-4 h-4 text-purple-600" />
                <span>Журнал рассылок</span>
                {invitations.filter(i => i.status === 'created').length > 0 && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                )}
              </button>

              {/* Tab 4 */}
              <button
                onClick={() => setActiveTab('settings')}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  activeTab === 'settings'
                    ? 'bg-white text-gray-900 shadow-sm'
                    : 'text-gray-500 hover:text-gray-800'
                }`}
              >
                <Settings className="w-4 h-4 text-amber-600" />
                <span>Шаблоны и правила</span>
              </button>
            </div>

            {/* Quick reset/demo control */}
            <button
              onClick={handleResetData}
              className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg hover:bg-gray-50 transition-all font-medium self-end sm:self-auto"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Сбросить демо-данные</span>
            </button>
          </div>

          {/* TFOMS Webhook Simulator widget */}
          <div className="bg-slate-900 border border-slate-950 text-slate-100 rounded-2xl shadow-md p-4 transition-all">
            <div className="flex items-center justify-between cursor-pointer select-none" onClick={() => setShowSimulator(!showSimulator)}>
              <div className="flex items-center gap-2.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <div>
                  <h4 className="text-xs font-bold tracking-wide flex items-center gap-1.5 text-slate-200">
                    🔌 Интеграционный шлюз ТФОМС (Webhook-симулятор события «service_provided»)
                  </h4>
                  <p className="text-[10px] text-slate-400">Симулирует автоматический отчет ТФОМС о прохождении скрининга в поликлинике</p>
                </div>
              </div>
              <button className="text-[10px] bg-slate-800 hover:bg-slate-700 border border-slate-700 px-2 py-1 rounded text-slate-300 font-bold transition-all">
                {showSimulator ? 'Свернуть' : 'Развернуть симулятор'}
              </button>
            </div>

            {showSimulator && (
              <div className="mt-4 pt-4 border-t border-slate-850 grid grid-cols-1 md:grid-cols-3 gap-4 items-end text-xs text-slate-300">
                <div className="space-y-1.5 col-span-1 md:col-span-2">
                  <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    Выберите активное направление для завершения:
                  </label>
                  {(() => {
                    const activeInvites = invitations.filter(inv => inv.status !== 'completed' && inv.status !== 'cancelled');
                    if (activeInvites.length === 0) {
                      return (
                        <div className="text-[11px] text-slate-400 italic bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
                          Нет активных (незавершенных) направлений в системе. Пожалуйста, сформируйте новое назначение в разделе «Пациенты и отбор».
                        </div>
                      );
                    }

                    return (
                      <select
                        value={selectedSimInviteId}
                        onChange={(e) => setSelectedSimInviteId(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-slate-800 border border-slate-750 rounded-lg text-slate-100 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                        id="webhook-invite-select"
                      >
                        <option value="">-- Выберите направление --</option>
                        {activeInvites.map(inv => {
                          const patient = patients.find(p => p.id === inv.patient_id);
                          const type = SCREENING_TYPES.find(t => t.id === inv.screening_type);
                          return (
                            <option key={inv.id} value={inv.id}>
                              [{inv.id}] {patient?.fullName || 'Пациент'} — {type?.name || inv.screening_type} ({inv.status})
                            </option>
                          );
                        })}
                      </select>
                    );
                  })()}
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    Код оказанной услуги ТФОМС:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="srv-XXXX"
                      value={simServiceId}
                      onChange={(e) => setSimServiceId(e.target.value)}
                      disabled={!selectedSimInviteId}
                      className="w-full text-xs px-3 py-2 bg-slate-800 border border-slate-750 rounded-lg text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                      id="webhook-service-id"
                    />
                    <button
                      onClick={handleSimulateWebhook}
                      disabled={!selectedSimInviteId || simIsLoading}
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-lg transition-colors flex items-center justify-center gap-1 shrink-0 disabled:opacity-40 disabled:hover:bg-emerald-500 text-[11px]"
                      id="webhook-simulate-btn"
                    >
                      {simIsLoading ? 'Сверка...' : 'Отправить Webhook'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* ACTIVE MODULE CONTAINER */}
          <div className="transition-all duration-300">
            {activeTab === 'analytics' && (
              <AnalyticsDashboard
                invitations={invitations}
                patients={patients}
              />
            )}

            {activeTab === 'patients' && (
              <PatientSelectorAndAutoTrigger
                patients={patients}
                invitations={invitations}
                criteria={criteria}
                onCreateInvitation={handleCreateInvitation}
                currentUserRole={currentUser.role}
                currentUserId={currentUser.id}
              />
            )}

            {activeTab === 'invitations' && (
              <InvitationList
                invitations={invitations}
                patients={patients}
                templates={templates}
                onUpdateStatus={handleUpdateStatus}
                onRescheduleInvitation={handleRescheduleInvitation}
                currentUserRole={currentUser.role}
                currentUserId={currentUser.id}
                onSendInvitation={handleSendInvitation}
                globalChannelPriority={channelPriority}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsTemplates
                criteria={criteria}
                templates={templates}
                onUpdateCriteria={handleUpdateCriteria}
                onUpdateTemplates={handleUpdateTemplates}
                currentUserRole={currentUser.role}
                channelPriority={channelPriority}
                onUpdateChannelPriority={handleUpdateChannelPriority}
              />
            )}
          </div>
        </main>
      </div>

      {/* FOOTER */}
      <footer className="bg-white border-t border-gray-100 py-6 mt-12 text-center text-xs text-gray-400">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2026 ГБУЗ «Медицинский информационно-аналитический центр». Все права защищены.</p>
          <p className="mt-1">Программный комплекс КМИС РБ — Подсистема профилактических скринингов населения v3.4.1</p>
        </div>
      </footer>
    </div>
  );
}
